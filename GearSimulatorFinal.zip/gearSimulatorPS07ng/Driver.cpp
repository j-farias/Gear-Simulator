#include <sstream>
#include <chrono>
#include <thread>

#include "GearSimulator.h"  // including here DOES NOT create an inclusion loop

#include "Driver.h"

using namespace std;

void Driver::readFile(std::ifstream& input)
{
	string wholeLineString;
	bool continueReading = true;

	while (continueReading && !input.eof()) {
		getline(input, wholeLineString);
		int colonLocation = wholeLineString.find(":");

		if (wholeLineString.find("driverID:") != string::npos) {
			driverID = StringPlus::trim(
				wholeLineString.substr(colonLocation + 1));
		}
		else if (wholeLineString.find("cyclical:") != string::npos)
			cyclical = wholeLineString.find("true") != string::npos; // 

		else if (wholeLineString.find("Input Motion:") != string::npos) {
			inputMotion = new Shape2D(input);  // note: I made changes to Shape2D constructor

		}
	}
}

void Driver::simulate(float timeStep, System::Windows::Forms::Form^ theSimulator)
{
	if (inputMotion != nullptr && drivenGear != nullptr) {
		auto start = std::chrono::system_clock::now();
		long long elapsedTime, timeInterval = timeStep * 1e9; // nanoseconds

		// since this function is also used to restart simulation, do not reset currTime
		// currTime = 0.f;

		simulationIsRunning = true;
		float maxTime = inputMotion->upperBoundingBox().x;

		float lookUpTime = currTime;

		if (cyclical)
			lookUpTime = fmodf(currTime, maxTime);

		// for cyclical, need these to splice motion from end of motion definition
		// to start of definition
		float prevLookUpTime = lookUpTime;   // used to detect needed splice
		float firstRot = inputMotion->getYgivenX(0.f);
		float lastRot = inputMotion->getYgivenX(maxTime); // this required changes in getYgivenX() function

		float prevRot = inputMotion->getYgivenX(lookUpTime); // change of variable name
		float thisRot;


		while (simulationIsRunning) {

			currTime += timeStep;


			if (cyclical) 
				lookUpTime = fmodf(currTime, maxTime);
			else
				lookUpTime = currTime;
			
			thisRot = inputMotion->getYgivenX(lookUpTime);

			if (prevRot > -INFINITY && thisRot > -INFINITY) {

				if (cyclical && prevLookUpTime > lookUpTime) // need the splice on motion
					drivenGear->rotate((thisRot - firstRot) + (lastRot - prevRot));
				else
					drivenGear->rotate(thisRot - prevRot);

				// elapsed time (in nanosecs) for this simulation step < time interval, then wait
				elapsedTime = std::chrono::nanoseconds(std::chrono::system_clock::now() - start).count();

				// put thread to sleep for remainer of time interval (timeInterval - elapsedTime)
				std::this_thread::sleep_for(std::chrono::nanoseconds(timeInterval - elapsedTime));

				// start the timer for next cycle (so that it includes all process, including graphics refresh)
				start = std::chrono::system_clock::now();

				if (elapsedTime > timeInterval) {
					// tell GearSimulator to display a message on feedbackLabel
					// cast a "form" into a "GearSimulator" to use its functions
					((gearSimulatorPS07ng::GearSimulator^)theSimulator)->showFeedback(
						"Interval too small, simulation not realtime");
				}
				else {
					((gearSimulatorPS07ng::GearSimulator^)theSimulator)->showFeedback("Simulation running. Time = "
						+ currTime.ToString("0.00") + ", Rotation = " + thisRot.ToString("0.00"));
				}

				((gearSimulatorPS07ng::GearSimulator^)theSimulator)->refreshAll();
				
				// prepare for next step
				prevRot = thisRot;
				prevLookUpTime = lookUpTime;
			}
			else
				simulationIsRunning = false;
		}

		// the word "Done" is used to change the simulation button from "Stop" to "Go"
		((gearSimulatorPS07ng::GearSimulator^)theSimulator)->showFeedback("Simulation Done. Time = "
			+ currTime.ToString("0.00") + ", Rotation = " + thisRot.ToString("0.00"));

	}
	else {
		((gearSimulatorPS07ng::GearSimulator^)theSimulator)->showFeedback("Cannot run simulation. Done.");
	}
}

std::ostream& operator<<(std::ostream& os, const Driver& aDriver)
{
	os << "Driver: " << endl;
	os << "\tdriverID: " << aDriver.driverID << endl;

	os << "\tcyclical: ";
	if (aDriver.cyclical)
		os << "true";
	else
		os << "false";

	if (aDriver.inputMotion != nullptr) {
		os << "\nInput Motion:" << endl;
		os << *(aDriver.inputMotion);
		os << "\End Input Motion:" << endl;
	}

	return os;
}
