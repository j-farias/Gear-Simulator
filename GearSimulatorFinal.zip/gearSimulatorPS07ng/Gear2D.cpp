#include <sstream>
#include "Gear2D.h"
#include "ColorConverter.h"
#include "StringPlus.h"
#include <iostream>


using namespace std;
using namespace System::Drawing;
using namespace System::Collections::Generic;

const float PI = 3.14159265; // can also use Math::PI
const float ADDENDUMFACTOR = 1.00;  // addendum = 1/pitch
const float DEDENDUMFACTOR = 1.25;  // dedendum = 1.25/pitch
const float MESHTOLERANCE = 0.01;   // inches
const float EPSILON = 10e-8;
const float PRESSUREANGLE = 20.0;  // used for involute base circle


std::vector<Point2D> beltPoints;
Point2D fillerPoint = { -1,-1 };

Gear2D::Gear2D()
{
	minX = minY = maxX = maxY = area = perimeter = 0.f;
	toothProfile = nullptr;
	startAngle = prevAngle = currAngle = 0.f;
	pitch = 2.f;
	numbTeeth = 10;
	colorH = 0.f; colorS = 1.0f; colorV = 1.0f; // red
	location = { 0.f, 0.f };
	recalcGear();
}

Gear2D::~Gear2D()
{
	// tell all attached gears to forget about me
	unmeshAll();

	// tell all meshed gears to forget about me
	unmeshAll();

	// delete toothProfile if there is one
	if (toothProfile != nullptr)
		delete toothProfile;

}

void Gear2D::readFile(std::ifstream& input)
{
	string wholeLineString;
	stringstream wholeLineStream;
	bool continueReading = true;

	while (continueReading && !input.eof()) {
		getline(input, wholeLineString);
		int colonLocation = wholeLineString.find(":");
		if (colonLocation != string::npos)
			wholeLineStream.str(wholeLineString.substr(colonLocation + 1));

		if (wholeLineString.find("gearID") != string::npos) {
			gearID = StringPlus::trim(
				wholeLineString.substr(colonLocation + 1));
		}
		else if (wholeLineString.find("pitch") != string::npos)
			wholeLineStream >> pitch;
		else if (wholeLineString.find("numbTeeth") != string::npos)
			wholeLineStream >> numbTeeth;
		else if (wholeLineString.find("location") != string::npos)
			wholeLineStream >> location.x >> location.y;
		else if (wholeLineString.find("startAngle") != string::npos)
			wholeLineStream >> startAngle;
		else if (wholeLineString.find("color") != string::npos)
			wholeLineStream >> colorH >> colorS >> colorV;

		else if (wholeLineString.find("End Gear") != string::npos)
			continueReading = false;

		wholeLineStream.clear();
	}

	reset();
	recalcGear();
}

void Gear2D::reset()
{
	prevAngle = currAngle = startAngle;
}

void Gear2D::generateToothProfile()
{
	// get some constants in here
	float rPitch = getPitchDiam() / 2.;
	float rDedendum = rPitch - DEDENDUMFACTOR / pitch;
	float rAddendum = rPitch + ADDENDUMFACTOR / pitch;
	float toothRot = 360. / 4. / numbTeeth * 1.1;
	float toothRotRad = toothRot * PI / 180.;
	float rBase = rPitch * cos(PRESSUREANGLE * PI / 180.);
	float alphaRad = 1.5 * PI / 180.;  // keep as radians so sin and cos can be used directly

	if (rBase < rDedendum)
		rBase = rBase;

	// now I see that calculating dist is much simpler
	// dist is simply a fraction of total circumference [ alphaRad / (2*PI) ] * (2*PI*R) 
	float dist = rBase * alphaRad;

	// variables for use in while loop
	float x_i = 0.f, y_i = 0.f;
	float x_iRot, y_iRot;

	// prepare a new shape to hold the output
	if (toothProfile != nullptr)
		delete toothProfile;

	toothProfile = new Shape2D();

	// put in some in-between-tooth points
	float extraX[7];
	float extraRad[7];
	int extraPntCount = 0;

	extraPntCount++; // 1  half way to other tooth, along dedundum
	extraX[extraPntCount] = rDedendum;
	extraRad[extraPntCount] = -PI / numbTeeth;

	extraPntCount++; // 2  quarter way to other tooth, along dedundum
	extraX[extraPntCount] = rDedendum;
	extraRad[extraPntCount] = (-PI / numbTeeth - toothRotRad) / 2.;

	extraPntCount++; // 3 fillet between points 2 and 4
	float filletFactor = 1. - sqrt(2.) / 2.;
	extraX[extraPntCount] = rDedendum + (rBase - rDedendum) / 2. * filletFactor;
	extraRad[extraPntCount] = -toothRotRad - (-toothRotRad - extraRad[2]) * filletFactor;

	extraPntCount++;  // 4  just under start of involute, halfway between dedundum and base circle
	extraX[extraPntCount] = (rDedendum + rBase) / 2.; y_i = 0;
	extraRad[extraPntCount] = -toothRotRad;

	float xRot, yRot;
	for (int i = 1; i <= extraPntCount; i++) {
		xRot = extraX[i] * cos(extraRad[i]);  // don't need the y part since y==0 always 
		yRot = extraX[i] * sin(extraRad[i]);
		toothProfile->addPoint(xRot, yRot, i);
		toothProfile->addPoint(xRot, -yRot, i + 1);
	}


	// calculate involute points
	int i = 0;
	x_i = rBase; y_i = 0;  // first point of involute

	while (sqrt(x_i * x_i + y_i * y_i) < rAddendum) {
		// using straight calculation
		x_iRot = x_i * cos(-toothRotRad) - y_i * sin(-toothRotRad);
		y_iRot = x_i * sin(-toothRotRad) + y_i * cos(-toothRotRad);

		// using Line2D functions
		//Point2D rotated = Line2D::rotatePoint({ x_i,y_i }, { 0,0 }, -toothRot);
		//x_iRot = rotated.x;
		//y_iRot = rotated.y;

		// add two points to shape (allow for extra points too)
		// first point is at (i+1)th ( when i = 0, 1, 2  : index = 1, 2, 3 )		
		toothProfile->addPoint(x_iRot, y_iRot, i + 1 + extraPntCount);
		// second point is at (i+2)th ( when i = 0, 1, 2  : index = 2, 3, 4 )		
		toothProfile->addPoint(x_iRot, -y_iRot, i + 2 + extraPntCount);

		i++;
		x_i = rBase * cos(i * alphaRad) + i * dist * sin(i * alphaRad);
		y_i = rBase * sin(i * alphaRad) - i * dist * cos(i * alphaRad);

	}

	//// add points on addendum itself (decided against this)
	//toothProfile->addPoint(x_iRot, y_iRot *0.9f, i + 1 + extraPntCount);
	//toothProfile->addPoint(x_iRot, -y_iRot *0.9f, i + 2 + extraPntCount);

	// the following expands toothProfile so that it makes the whole gear
	// using the Shape2D instead of just one tooth
	int numbPoints = toothProfile->getNumbPoints();  // obvious new function in Shape2D.h
	int totalPoints = numbPoints * numbTeeth + 10;
	float toothAngle = 360.0f / numbTeeth;
	for (int i = 1; i < numbTeeth; i++) {
		for (int j = 1; j <= numbPoints; j++) {
			//Point2D rotated = Line2D::rotatePoint({ x_i,y_i }, { 0,0 }, -toothRot);
			toothProfile->addPoint(Line2D::rotatePoint(toothProfile->getPoint(j + 1),
				{ 0.,0. }, i * toothAngle), totalPoints); // always add ad end
		}
	}
}

void Gear2D::paint(System::Drawing::Graphics^ g, System::Drawing::Color^ c, bool showGearID, bool
	showTeethLabels, bool showCircles, bool fillGear, bool transparent)
{
	Pen^ thePen;

	if (c == nullptr)
		c = ColorNG::colorFromHSV(colorH, colorS, colorV);

	thePen = gcnew Pen(*c, 0.);

	g->TranslateTransform(location.x, location.y);
	g->RotateTransform(currAngle);

	float stepAngle = 360.f / numbTeeth;
	float toothAngle = 0.f;
	float rPitch = getPitchDiam() / 2.;
	float rDedendum = rPitch - DEDENDUMFACTOR / pitch;
	float rAddendum = rPitch + ADDENDUMFACTOR / pitch;
	float rBase = rPitch * cos(PRESSUREANGLE * PI / 180.);

	// stuff for labels
	//float textSize = ADDENDUMFACTOR / pitch * 0.6;
	float textSize = rPitch / 15.f;  // the 15 came from trial and error
	PointF drawPoint = PointF(0, 0);
	StringFormat^ format = gcnew StringFormat();
	format->LineAlignment = StringAlignment::Center;
	format->Alignment = StringAlignment::Center;
	System::Drawing::Font^ drawFont = gcnew System::Drawing::Font("Arial", textSize);
	SolidBrush^ drawBrush = gcnew SolidBrush(Color::Black);

	if (toothProfile == nullptr) {
		if (fillGear) {
			SolidBrush^ theBrush = gcnew SolidBrush(*c);
			g->FillEllipse(theBrush, -rPitch, -rPitch, 2. * rPitch, 2. * rPitch); // just draw filled-npitch circle
		}
		else
			g->DrawEllipse(thePen, -rPitch, -rPitch, 2. * rPitch, 2. * rPitch); // just draw pitch circle 
	}

	// keep this here in case I need it later
	//float currScale0 = g->Transform->Elements[0]; // getting info from the graphics object
	//float currScale1 = g->Transform->Elements[1]; // getting info from the graphics object
	//float currScale = sqrt(currScale0 * currScale0 + currScale1 * currScale1);
	//float currRotation = -atan2(currScale1, currScale0) * 45. / atan(1.);

	if (toothProfile != nullptr)
		toothProfile->paint(g, *c, false, 0.f, fillGear, false, true, transparent);

	for (int i = 0; i < numbTeeth; i++) {
		if (toothProfile == nullptr) { // just draw a little spike
			g->DrawLine(thePen, rDedendum, 0., rAddendum, 0.);
		}
		//else
		//	toothProfile->paint(g, *c, false, 0.f, fillGear, false, true, transparent);

		// tooth labels (unrotated so they are never upsidedown)
		if (showTeethLabels) {
			g->TranslateTransform(rAddendum + textSize * 1.0, 0.);
			g->RotateTransform(-i * stepAngle - currAngle);
			g->ScaleTransform(1., -1.);

			g->DrawString((i + 1).ToString(), drawFont, drawBrush, drawPoint, format);

			g->ScaleTransform(1., -1.);
			g->RotateTransform(i * stepAngle + currAngle);
			g->TranslateTransform(-(rAddendum + textSize * 1.0), 0.);
		}

		g->RotateTransform(stepAngle);

	}

	//if (fillGear) {

	//	SolidBrush^ theBrush;
	//	if (transparent)
	//		theBrush = gcnew SolidBrush(Color::FromArgb(100, *c));
	//	else
	//		theBrush = gcnew SolidBrush(*c);

	//	if (toothProfile != nullptr) {
	//		// circle doesn't work well when using transparency
	//		if (transparent) {
	//			Point2D vertex = toothProfile->getPoint(1);
	//			// to draw "continuous" shape
	//			// put all points into special array of type cli::array
	//			cli::array<PointF>^ pointArray = gcnew cli::array<PointF>(3);
	//			pointArray[0] = PointF(0, 0);
	//			pointArray[1] = PointF(vertex.x, vertex.y);
	//			pointArray[2] = PointF(vertex.x, -vertex.y);

	//			for (int i = 0; i < numbTeeth; i++) {
	//				g->FillPolygon(theBrush, pointArray);
	//				g->RotateTransform(stepAngle);
	//			}
	//		}
	//		else 
	//			g->FillEllipse(theBrush, -rDedendum, -rDedendum, 2. * rDedendum, 2. * rDedendum);
	//	}
	//	else {		
	//		// draw a filled circle right at dedendum
	//		g->FillEllipse(theBrush, -rDedendum, -rDedendum, 2. * rDedendum, 2. * rDedendum);

	//	}
	//}

	if (showGearID) {
		// show circle and crosshairs at center of gear
		Pen^ centerPen;
		if (fillGear)
			centerPen = gcnew Pen(Color::Black, 0.f);
		else
			centerPen = thePen;

		g->DrawLine(centerPen, -textSize * 1.2, 0.f, textSize * 1.6, 0.f); // slight point to 1st tooth
		g->DrawLine(centerPen, 0.f, -textSize * 1.2, 0.f, textSize * 1.2);
		g->DrawEllipse(centerPen, -textSize, -textSize, textSize * 2, textSize * 2);
	}

	g->RotateTransform(-currAngle); // from this point on, everything drawn will be "unrotated"

	if (showGearID) {
		// display gearID a bit off center
		PointF labelPoint = PointF(textSize * 2, textSize * 1);
		g->ScaleTransform(1., -1.);
		g->DrawString(gcnew System::String(gearID.c_str()), drawFont, drawBrush, labelPoint/*, format*/);
		g->ScaleTransform(1., -1.);
	}

	if (showCircles) {
		thePen->Color = Color::Gray;

		// tooth delimiters for debugging only (set to "false" to skip)
		if (false) {
			g->RotateTransform(currAngle);
			for (int i = 0; i < numbTeeth; i++) {
				g->DrawLine(thePen, rBase, 0., rAddendum, 0.);
				g->RotateTransform(stepAngle / 2.);
				g->DrawLine(thePen, rBase, 0., rAddendum, 0.);
				g->RotateTransform(stepAngle / 2.);

			}
			g->RotateTransform(-currAngle);
		}

		// set up some dash patterns
		cli::array<float>^ longShort = gcnew cli::array<float>(4) { 20.0F, 6.0F, 10.0F, 6.0F };
		cli::array<float>^ longGap = gcnew cli::array<float>(4) { 15.0F, 15.0F, 15.0F, 15.0F };

		// draw pitch circle, no dashes
		g->DrawEllipse(thePen, -rPitch, -rPitch, 2. * rPitch, 2. * rPitch);

		// draw addendum circle, long gap dashes
		thePen->DashPattern = longGap;

		g->DrawEllipse(thePen, -rAddendum, -rAddendum, 2. * rAddendum, 2. * rAddendum);

		// draw base circle and dedendum circles, long-short dashes
		thePen->DashPattern = longShort;
		g->DrawEllipse(thePen, -rBase, -rBase, 2. * rBase, 2. * rBase);
		g->DrawEllipse(thePen, -rDedendum, -rDedendum, 2. * rDedendum, 2. * rDedendum);

	}

	//float x1 = 24.5;
	//float y1 = 12.7;
	//float x2 = 18.2;
	//float y2 = 2.1;

	g->TranslateTransform(-location.x, -location.y);
	/*g->DrawLine(gcnew Pen(Color::Black, 0), x1, y1, x2, y2);*/

	if (beltPoints.size() > 0) {
		for (size_t i = 0; i < beltPoints.size() - 1; i++)
		{
			if ((beltPoints[i].x == fillerPoint.x && beltPoints[i].y == fillerPoint.y) ||
				(beltPoints[i + 1].x == fillerPoint.x && beltPoints[i + 1].y == fillerPoint.y)) {
				continue;
			}
			else {
				g->DrawLine(gcnew Pen(Color::Black, 0), beltPoints[i].x, beltPoints[i].y, beltPoints[i + 1].x, beltPoints[i + 1].y);
			}
		}
	}
	

}

void Gear2D::paintLine(System::Drawing::Graphics^ g, float x1, float y1, float x2, float y2)
{

	//g->TranslateTransform(location.x, location.y);
	//g->RotateTransform(currAngle);

	g->DrawLine(gcnew Pen(Color::Black, 0.), x1, y1, x2, y2);
}



bool Gear2D::isContained(Point2D givenCoord) const
{
	float distToCenter = Line2D::getLength(givenCoord, location);
	float rAddendum = getPitchDiam() / 2. + ADDENDUMFACTOR / pitch;
	float rDedendum = getPitchDiam() / 2. - DEDENDUMFACTOR / pitch;

	if (distToCenter > rAddendum) // given point is too far from gear center
		return false;
	else if (distToCenter <= rDedendum) // given point is inside dedendum diameter
		return true;
	else {
		// given point may be on a tooth 
		if (toothProfile == nullptr)
			return false;
		else {
			// now that we define whole gear shape, just convert to local gear coords
			// (including rotation) and check Shape2D directly
			Point2D localPnt = { givenCoord.x - location.x , givenCoord.y - location.y };
			localPnt = Line2D::rotatePoint(localPnt, { 0.f,0.f }, -currAngle);
			return toothProfile->isContained(localPnt);

			//// rotate coords to "first tooth" location and check against toothProfile

			//// think about it like this:
			//	// find nearest tooth and measure angle to it (use modulo)
			//	// use distToCenter to get transformedPnt at that distance and angle from x-axis
			//float angleToCenter = Line2D::getAngle(location, givenCoord);
			//float stepAngle = 360. / numbTeeth;
			//Point2D transformedPnt;

			//angleToCenter -= currAngle; // to account for current rotation

			//float adjustedAngle = fmodf(angleToCenter, stepAngle); // this is angle from point to previous tooth
			//if (adjustedAngle > stepAngle / 2.) // it is closer to "next" tooth make it "before" tooth
			//	adjustedAngle -= stepAngle;

			//// get coordinates equivalent to a position near the "first" tooth on x-axis of gear
			//transformedPnt.x = distToCenter * cos(adjustedAngle * PI / 180.);
			//transformedPnt.y = distToCenter * sin(adjustedAngle * PI / 180.);

			//return toothProfile->isContained(transformedPnt);
		}
	}
}

std::string Gear2D::getDescription() const
{
	stringstream descrip;
	descrip << "   ID: " << gearID << endl;
	descrip << "    N: " << numbTeeth << endl;;
	descrip << "    P: " << StringPlus::roundToSigFigs(pitch, 3) << endl;;
	descrip << "  loc: " << StringPlus::roundToSigFigs(location.x, 3)
		<< ", " << StringPlus::roundToSigFigs(location.y, 3) << endl;;
	descrip << "strtA: " << StringPlus::roundToSigFigs(startAngle, 3) << endl;;
	descrip << "currA: " << StringPlus::roundToSigFigs(currAngle, 3) << endl;;

	return descrip.str();
}

System::Drawing::Color^ Gear2D::getColor() const
{
	return ColorNG::colorFromHSV(colorH, colorS, colorV);
}

bool Gear2D::isMeshableWith(const Gear2D& otherGear) const
{
	// there may be other reasons gears can be meshable,
	// so it's better to put rules in Gear2D class
	return pitch == otherGear.getPitch();
}

bool Gear2D::meshWith(Gear2D& otherGear)
{
	if (isMeshableWith(otherGear)) {
		bool foundGear = false;
		for (auto currGear : meshedInto) {
			if (currGear == &otherGear) {
				foundGear = true;
				break;      // exit for-loop
			}
		}

		if (!foundGear) {
			float pDiam = getPitchDiam();
			Point2D otherLoc = otherGear.getLocation();
			float pDiamOther = otherGear.getPitchDiam();
			float oldDistance = Line2D::getLength(location, otherLoc);
			float alphaDeg = Line2D::getAngle(location, otherLoc);
			float newDistance = (pDiam + pDiamOther) / 2.f;
			float toothAngle = 360.f / numbTeeth;

			float adjustOther = otherGear.getStartAngle() - (alphaDeg - 180.f);

			// change this gear to mesh into other gear
			//location = Line2D::scale(otherLoc, location, newDistance / oldDistance);

			Point2D newLoc = Line2D::scale(otherLoc, location, newDistance / oldDistance);
			Point2D delta = { newLoc.x - location.x, newLoc.y - location.y };
			move(delta);

			startAngle = alphaDeg + toothAngle / 2.f
				- adjustOther * pDiamOther / pDiam;
			startAngle = fmodf(startAngle + 360.f, 360.f);
			currAngle = startAngle;

			// add to vector
			meshedInto.push_back(&otherGear);

			// set up bidirectional relationship. Can only do this because private members
			// of other instances of this same class are still accessible
			otherGear.meshedInto.push_back(this);
		}

		return !foundGear;
	}
	else
		return false;
}

bool Gear2D::attachTo(Gear2D& otherGear)
{
	bool foundGear = false;
	for (auto currGear : attachedTo) {
		if (currGear == &otherGear) {
			foundGear = true;
			break;      // exit for-loop
		}
	}

	if (!foundGear) {
		Point2D otherLoc = otherGear.getLocation();
		Point2D delta = { otherLoc.x - location.x, otherLoc.y - location.y };
		move(delta);
		attachedTo.push_back(&otherGear);
		otherGear.attachedTo.push_back(this);  // just make connection without fancy stuff
	}

	return !foundGear;
}

bool Gear2D::beltTo(Gear2D& otherGear)
{
	bool foundGear = false;
	for (auto currGear : beltedTo) {
		if (currGear == &otherGear) {
			foundGear = true;
			break;      // exit for-loop
		}
	}
	if (!foundGear) {
		beltPoints.push_back(location);
		beltPoints.push_back(otherGear.location);
		beltPoints.push_back(fillerPoint);
		beltedTo.push_back(&otherGear);
		otherGear.beltedTo.push_back(this);  // just make connection without fancy stuff
	}
	return !foundGear;
}

bool Gear2D::unmeshWith(Gear2D& otherGear)
{
	int i = 0;
	for (auto currGear : meshedInto) {
		if (currGear == &otherGear) {
			meshedInto.erase(meshedInto.begin() + i);
			currGear->unmeshWith(*this);
			return true;
		}
		i++;
	}
	return false;
}
bool Gear2D::unmeshAll()
{
	for (auto currGear : meshedInto) {
		currGear->unmeshWith(*this);
	}
	return true;
}

bool Gear2D::unattachTo(Gear2D& otherGear)
{
	int i = 0;
	for (auto currGear : attachedTo) {
		if (currGear == &otherGear) {
			attachedTo.erase(attachedTo.begin() + i);
			currGear->unattachTo(*this);
			return true;
		}
		i++;
	}
	return false;
}

bool Gear2D::unbeltWith(Gear2D& otherGear)
{
	int i = 0;
	for (auto currGear : beltedTo) {
		if (currGear == &otherGear) {
			beltedTo.erase(beltedTo.begin() + i);
			beltPoints = {};
			currGear->unbeltWith(*this);
			return true;
		}
		i++;
	}
	return false;
}

bool Gear2D::unattachAll()
{
	for (auto currGear : attachedTo) {
		currGear->unattachTo(*this);
	}
	return true;
}

bool Gear2D::unbeltAll()
{
	for (auto currGear : beltedTo) {
		currGear->unbeltWith(*this);
	}
	return true;
}

void Gear2D::rotate(float angle, Gear2D* drivingGear)
{
	// don't do anything if the angle of rotation is zero

	if (fabs(angle) > 1e-7) {
		prevAngle = currAngle;
		currAngle += angle;

		// propagation to attached gears
		for (auto currGear : attachedTo) {
			if (drivingGear == nullptr || currGear != drivingGear) {
				currGear->rotate(angle, this);
			}
		}

		// propagation to meshed gears
		for (auto currGear : meshedInto) {
			if (drivingGear == nullptr || currGear != drivingGear) {
				float pDiamOther = currGear->getPitchDiam();
				float otherRotAngle = -angle * getPitchDiam() / pDiamOther;
				currGear->rotate(otherRotAngle, this);
			}
		}

		//propagation for belted gears
		for (auto currGear : beltedTo) {
			if (drivingGear == nullptr || currGear != drivingGear) {
				float pDiamOther = currGear->getPitchDiam();
				float otherRotAngle = angle * getPitchDiam() / pDiamOther; //not negative since going in the same direction
				currGear->rotate(otherRotAngle, this);
			}
		}
	}
}

void Gear2D::move(Point2D delta, Gear2D* drivingGear)
{
	// don't do anything, if the delta is zero

	if (fabs(delta.x) > 1e-7 && fabs(delta.y) > 1e-7) {
		location.x += delta.x;
		location.y += delta.y;
		//recalcGear();

		// propagation to attached gears
		for (auto currGear : attachedTo) {
			if (drivingGear == nullptr || currGear != drivingGear) {
				currGear->move(delta, this);
			}
		}

		// propagation to meshed gears
		for (auto currGear : meshedInto) {
			if (drivingGear == nullptr || currGear != drivingGear) {
				currGear->move(delta, this);
			}
		}
	}
}

std::string Gear2D::listMeshedGears()
{
	string fullList = "";
	for (auto currGear : meshedInto) {
		fullList += "\t" + gearID + "\t" + currGear->gearID + "\n"; // allowed to get private member of same class
	}
	return fullList;
}

std::string Gear2D::listAttachedGears()
{
	string fullList = "";
	for (auto currGear : attachedTo) {
		fullList += "\t" + gearID + "\t" + currGear->gearID + "\n"; // allowed to get private member of same class
	}
	return fullList;
}

std::string Gear2D::listBeltedGears()
{
	string fullList = "";
	for (auto currGear : beltedTo) {
		fullList += "\t" + gearID + "\t" + currGear->gearID + "\n"; // allowed to get private member of same class
	}
	return fullList;
}

void Gear2D::recalcGear()
{
	float rAddendum = getPitchDiam() / 2. + ADDENDUMFACTOR / pitch;
	minX = location.x - rAddendum;
	maxX = location.x + rAddendum;
	minY = location.y - rAddendum;
	maxY = location.y + rAddendum;

	generateToothProfile();

	area = perimeter = 0.f;
	if (toothProfile != nullptr) {
		// polygon is made up of several isosceles triangles 
		Point2D nearestPnt = toothProfile->getPoint(1);
		float sideLength = -nearestPnt.y * 2.; // easy to get due to symmetry about x-axis
		float insideRadius = nearestPnt.x;  // easy to get due to symmetry about x-axis
		// for area, need area of teeth and area of polygon inside teeth
		area = numbTeeth * toothProfile->area();
		area += numbTeeth * sideLength * insideRadius / 2.;

		perimeter = numbTeeth * (toothProfile->perimeter() - sideLength);

	}
}

std::ostream& operator<<(std::ostream& os, const Gear2D& aGear)
{
	os.precision(6);
	os << "Gear: " << endl;
	os << "\tgearID: " << aGear.gearID << endl;
	os << "\tpitch: " << aGear.pitch << endl;
	os << "\tnumbTeeth: " << aGear.numbTeeth << endl;
	os << "\tlocation: " << aGear.location.x << " " << aGear.location.y << endl;
	os << "\tstartAngle: " << aGear.startAngle << endl;
	os << "\tcolor: " << aGear.colorH << " " << aGear.colorS
		<< " " << aGear.colorV << endl;
	os << "End Gear :" << endl;

	return os;
}
