#include <iostream>
#include <sstream>
#include "Shape2D.h"
#include "ColorConverter.h"

using namespace std;
using namespace System::Drawing;
using namespace System::Collections::Generic;

Shape2D::Shape2D()
{
	// just initialize some values
	minX = maxX = minY = maxY = -INFINITY; // btw, this works because the "=" operator returns the value assigned
	shapeArea = shapePerim = 0.f;
}

Shape2D::Shape2D(std::ifstream& input)
{
	// as an extra feature, let's not allow duplicate subsequent coords 
	Point2D currPnt, prevPnt = { -INFINITY, -INFINITY };
	string wholeLineString;
	stringstream wholeLineStream;
	bool continueReading = true;

	while (continueReading && !input.eof()) {
		getline(input, wholeLineString);

		if (wholeLineString.find("End Input Motion:") != string::npos) {
			continueReading = false;
		}
		else {
			wholeLineStream.str(wholeLineString);
			//input >> currPnt.x >> currPnt.y;
			wholeLineStream >> currPnt.x >> currPnt.y;
			if (!(currPnt.x == prevPnt.x && currPnt.y == prevPnt.y))
				thePoints.push_back(currPnt);  // this actually makes a copy
			prevPnt = currPnt;
			wholeLineStream.clear();
		}
	}

	// recalculate shape parameters
	recalcShape();
}

bool Shape2D::addPoint(Point2D newPoint, int index)
{
	if (index <= 0)
		return false;
	else {
		if (index > thePoints.size())
			thePoints.push_back(newPoint);
		else
			thePoints.insert(thePoints.begin() + index - 1, newPoint);

		// probably need self-intersect check here too, but maybe later

		// recalculate shape parameters
		recalcShape();

		return true;
	}
}

bool Shape2D::addPoint(float newX, float newY, int index)
{
	return addPoint({ newX, newY }, index);
}

bool Shape2D::addPoint(int index, float ratio)
{
	// in coding, I realized that user should be able to insert a point between the first point and the last point
	// For this, I need to handle the index == 1 case carefully

	if (1 <= index && index <= thePoints.size()   // cannot use this to add at start
		&& 0. <= ratio && ratio <= 1.0) {
		//Point2D newPoint;
		//newPoint.x = thePoints[index - 2].x + (thePoints[index - 1].x - thePoints[index - 2].x) * ratio;
		//newPoint.y = thePoints[index - 2].y + (thePoints[index - 1].y - thePoints[index - 2].y) * ratio;
		//thePoints.insert(thePoints.begin() + index - 1, newPoint);

		Point2D forwardPnt = thePoints[index - 1], backPnt;
		if (index == 1)
			backPnt = thePoints.back();
		else
			backPnt = thePoints[index - 2];

		// using a new function in Line2D instead
		thePoints.insert(thePoints.begin() + index - 1,
			Line2D::scale(backPnt, forwardPnt, ratio));

		// recalculate shape parameters (not needed)
		//recalcShape();

		return true;
	}
	else
		return false;
}

bool Shape2D::removePoint(int index)
{
	if (index <= 0 || index > thePoints.size())
		return false;
	else {
		auto oldCoords = thePoints[index - 1];

		thePoints.erase(thePoints.begin() + index - 1);

		// check if removing point creates self intersect
		if (selfIntersects()) {
			thePoints.insert(thePoints.begin() + index - 1, oldCoords);
			return false;
		}
		else {
			// recalculate shape parameters
			recalcShape();

			return true;
		}
	}
}

Point2D Shape2D::getPoint(int index)
{
	if (index <= 0 || index > thePoints.size())
		return { -INFINITY, -INFINITY };
	else {
		return thePoints[index - 1];
	}
}

bool Shape2D::movePoint(Point2D newCoords, int index)
{
	if (index <= 0 || index > thePoints.size())
		return false;
	else {
		auto oldCoords = thePoints[index - 1];
		thePoints[index - 1] = newCoords;

		// check if move creates self intersect (not reqd for PS03)
		if (selfIntersects()) {
			thePoints[index - 1] = oldCoords;
			return false;
		}
		else {
			// recalculate shape parameters
			recalcShape();

			return true;
		}
	}
}

bool Shape2D::movePointDelta(Point2D deltaCoords, int index)
{
	if (index <= 0 || index > thePoints.size())
		return false;
	else {
		Point2D newCoords = { thePoints[index - 1].x + deltaCoords.x, thePoints[index - 1].y + deltaCoords.y };

		return movePoint(newCoords, index); // will check self-intersect too
	}
}

int Shape2D::getIndex(Point2D givenCoord, float dist)
{
	// first do a quick check to see if givenCoord is in ballpark
	if (givenCoord.x < minX - dist || givenCoord.x > maxX + dist
		|| givenCoord.y < minY - dist || givenCoord.y > maxY + dist)
		return -1;
	else {
		// now I really have to search for something
		bool foundIt = false;
		int currIndex = 0;
		while (!foundIt && currIndex < thePoints.size()) {
			foundIt = (givenCoord.x > thePoints[currIndex].x - dist && givenCoord.x < thePoints[currIndex].x + dist
				&& givenCoord.y > thePoints[currIndex].y - dist && givenCoord.y < thePoints[currIndex].y + dist);
			currIndex++;
		}

		if (foundIt)
			return currIndex;
		else
			return -1;
	}

}

void Shape2D::paint(System::Drawing::Graphics^ g, System::Drawing::Color c,
	bool showPoints, float width, bool fillShape, bool showLabel, bool openShape, bool transparent)
{
	if (thePoints.size() > 0) {
		// define a graphic pen
		Pen^ linePen = gcnew Pen(c, width);

		// easy way to generate shape graphics, although the joints look weird if width is thick
		//auto prevPnt = thePoints.back();
		//for (auto &currPnt : thePoints) {
		//	g->DrawLine(linePen, prevPnt.x, prevPnt.y, currPnt.x, currPnt.y);
		//	prevPnt = currPnt;
		//}

		// to draw "continuous" shape
		// put all points into special array of type cli::array
		cli::array<PointF>^ pointArray = gcnew cli::array<PointF>(thePoints.size());

		// load points into special array
		int i = 0;
		for (auto& currPnt : thePoints)
			pointArray[i++] = PointF(currPnt.x, currPnt.y); // note i++ increments i just after it is used as array index

		if (fillShape) {
			// I  generally don't like the trinary operator, but it works like this:
			//      condition ? value_if_true : value_if_false
			int alpha = transparent ? 100 : 255;

			// to fill the shape, we need a "brush" instead of a pen
			// I am using "solid" brush here, but it could be "texture" brush if I want to show an image
			SolidBrush^ shapeBrush = gcnew SolidBrush(Color::FromArgb(alpha, c));
			//SolidBrush^ shapeBrush = gcnew SolidBrush(c);
			
			g->FillPolygon(shapeBrush, pointArray);

			// draw the shape outline (in black) at the given width
			//if (openShape) // need to figure out how not to draw last line (look into drawcurve)
			//	g->DrawCurve(gcnew Pen(Color::Black, width), pointArray, 0.F);
			//else
			if (transparent)  // not quite correct to use transparent here, but it works for gears
				g->DrawCurve(gcnew Pen(Color::Black, width), pointArray, 0.0F);
			else
				g->DrawPolygon(gcnew Pen(Color::Black, width), pointArray);
		}
		else
			if (openShape)
				g->DrawCurve(linePen, pointArray, 0.0F);
			else
				// just draw the shape outline
				g->DrawPolygon(linePen, pointArray);

		if (showPoints) {
			for (int i = 1; i <= thePoints.size(); i++) {
				if (fillShape)
					paintPnt(i, g, Color::Black, showLabel);
				else
					paintPnt(i, g, c, showLabel);
			}
		}
	}

}

void Shape2D::paintPnt(int index, System::Drawing::Graphics^ g, System::Drawing::Color c,
	bool showLabel, int pixelSize, bool filled)
{
	if (index > 0 && index <= thePoints.size()) {
		auto currPnt = thePoints.at(index - 1);

		float pointDiam;

		// select diameter of point either using zoom scale or bypassing/ zoom scale
		bool scaleWithZoom = false;
		if (scaleWithZoom) {
			// based on zoom scale (point gets bigger when you zoom in, which I don't like)
			pointDiam = max((maxX - minX) / 40.f, (maxY - minY) / 40.f);
			pointDiam = max(pointDiam, 0.5f);  // don't want it too small 
		}
		else {
			// always same number of pixels (point stays the same size when you zoom in)
			float currScale0 = g->Transform->Elements[0]; // getting info from the graphics object
			float currScale1 = g->Transform->Elements[1]; // getting info from the graphics object
			float currScale = sqrt(currScale0 * currScale0 + currScale1 * currScale1);
			float currRotation = -atan2(currScale1, currScale0) * 45. / atan(1.);
			pointDiam = pixelSize / currScale;
		}

		// translate to point itself 
		// (this will make it easier later if I want a triangle or star or whatever)
		g->TranslateTransform(currPnt.x, currPnt.y);

		// draw circle
		//g->DrawEllipse(pointPen, -pointDiam / 2., -pointDiam / 2., pointDiam, pointDiam);

		// draw tilted square
		g->RotateTransform(45.);
		if (filled) {
			SolidBrush^ pointBrush = gcnew SolidBrush(c);
			g->FillRectangle(pointBrush, -pointDiam / 2., -pointDiam / 2., pointDiam, pointDiam);
		}
		else {
			Pen^ pointPen = gcnew Pen(c, 0);
			g->DrawRectangle(pointPen, -pointDiam / 2., -pointDiam / 2., pointDiam, pointDiam);
		}
		g->RotateTransform(-45.);

		if (showLabel) {
			// drawing the index number on the point, need font and brush
			System::Drawing::Font^ drawFont = gcnew System::Drawing::Font("Arial", pointDiam);
			SolidBrush^ drawBrush = gcnew SolidBrush(Color::Black);

			// need to scale so that y-axis is down (otherwise text will be upside down)
			g->ScaleTransform(1., -1.);

			// Create point for upper-left corner of text.
			PointF drawPoint = PointF(pointDiam * 0.5, pointDiam * 0.5); // a little to the right, a little down

			// Draw string to screen.
			g->DrawString(index.ToString(), drawFont, drawBrush, drawPoint);

			// scale back to our normal y-axis is upwards
			g->ScaleTransform(1., -1.);
		}

		// translate back to our normal drawing plane
		g->TranslateTransform(-currPnt.x, -currPnt.y);
	}
}

bool Shape2D::isContained(Point2D testPnt, bool isInclusive)
{
	if (thePoints.size() < 3 || testPnt.x < minX || testPnt.x > maxX
		|| testPnt.y < minY || testPnt.y > maxY)
		return false;
	else {
		const float TOLERANCE = 1e-6;
		bool tooHigh, tooLow, tooLeft;
		Point2D prevPnt = thePoints.back();
		int crossCount = 0;
		float crossX;

		for (auto currPnt : thePoints) {

			// check if segment is of interest
			tooHigh = min(currPnt.y, prevPnt.y) > testPnt.y;
			tooLow = max(currPnt.y, prevPnt.y) < testPnt.y;
			tooLeft = max(currPnt.x, prevPnt.x) < testPnt.x;
			if (!tooHigh && !tooLow && !tooLeft) { // segment is of interest

				// check for horz segment (avoid divide by zero error in crossX calc)
				if (fabs(currPnt.y - prevPnt.y) < TOLERANCE) {
					if (min(currPnt.x, prevPnt.x) <= testPnt.x) // test point on edge
						return isInclusive; // << possible exit from function

					// else segment can be ignored and just move onto next one
				}
				else { // process segment

					// calculate crossX
					crossX = prevPnt.x + (currPnt.x - prevPnt.x) * (testPnt.y - prevPnt.y)
						/ (currPnt.y - prevPnt.y);

					// check if point on edge
					if (fabs(crossX - testPnt.x) < TOLERANCE)
						return isInclusive;     // << possible exit from function

					else if (crossX > testPnt.x) { // be sure crossX is to right of testX
						// check if crossX on vertex and other point is above
						if ((fabs(testPnt.y - prevPnt.y) < TOLERANCE && currPnt.y > testPnt.y)
							|| (fabs(testPnt.y - currPnt.y) < TOLERANCE && prevPnt.y > testPnt.y)
							|| (fabs(testPnt.y - prevPnt.y) > TOLERANCE && fabs(testPnt.y - currPnt.y) > TOLERANCE))
							crossCount++;
					}
				}
			}

			// advance to next segment
			prevPnt = currPnt;
		}

		return (crossCount % 2 == 1);  // returns true if odd
	}

}

float Shape2D::getYgivenX(float wantedX)
{
	// quick check to avoid loop if possible
	if (wantedX < thePoints.front().x || wantedX > thePoints.back().x)
		return -INFINITY;

	// handle the special case of wantedX equal to last X value
	// which is not included in loop processing
	else if (wantedX == thePoints.back().x)
		return thePoints.back().y;
	else {
		// now look for point
		Point2D prevPnt = thePoints.front();
		for (auto currPnt : thePoints) {
			if (currPnt.x > wantedX) { // found an x-value greater than wantedX, time to interpolate
				float wantedY = prevPnt.y + (wantedX - prevPnt.x) * (currPnt.y - prevPnt.y) / (currPnt.x - prevPnt.x);
				return wantedY;  // possible exit from function
			}
			prevPnt = currPnt;
		}
	}

	// shoud never get herw
	return -INFINITY;
}

void Shape2D::recalcShape()
{
	// combining area, perimeter and bounding box in one loop
	if (thePoints.size() > 0) {

		// initialize variables
		shapeArea = shapePerim = 0.f;
		minX = thePoints.front().x;
		maxX = thePoints.back().x; // in case there are only 2 points
		minY = thePoints.front().y;
		maxY = thePoints.back().y; // in case there are only 2 points

		// loop to determine variables 
		if (thePoints.size() > 2) { // need at least 3 points
			Point2D prevPnt = thePoints.back(); // the last point
			for (auto& currPnt : thePoints) {
				if (currPnt.x < minX)
					minX = currPnt.x;
				if (currPnt.x > maxX)
					maxX = currPnt.x;
				if (currPnt.y < minY)
					minY = currPnt.y;
				if (currPnt.y > maxY)
					maxY = currPnt.y;

				float width = prevPnt.x - currPnt.x;
				shapeArea += (prevPnt.y + currPnt.y) / 2. * width;
				shapePerim += Line2D::getLength(prevPnt, currPnt);
				prevPnt = currPnt;
			}
		}
	}
}

bool Shape2D::selfIntersects()  // still have issues . . .
{
	bool foundSelfIntersect = false;

	if (thePoints.size() > 2) { // need at least 3 points
		Point2D currPnt, prevPnt = thePoints.back(); // the last point
		Point2D intersection;
		int lastJvalue = thePoints.size() - 1; // on the first pass, don't go to the last point

		for (int i = 0; i < thePoints.size() && !foundSelfIntersect; i++) {
			currPnt = thePoints[i];

			// note: cannot check intersection of adjacent segments since they always share a point
			//       therefore j index should start at i+2 and got to the last point 
			//		 (except on first pass when  

			for (int j = i + 2; j < lastJvalue && !foundSelfIntersect; j++) {
				intersection = Line2D::getTrueIntersection(prevPnt, currPnt, thePoints[j - 1], thePoints[j]);

				// if there is a true intersection, both for-loops should exit
				foundSelfIntersect = (intersection.x != -INFINITY);

				if (foundSelfIntersect)
					j = j;
			}
			lastJvalue = thePoints.size(); // on all other passes, go to the last point
			prevPnt = currPnt;
		}
	}

	return foundSelfIntersect;
}

std::ostream& operator<<(std::ostream& os, const Shape2D& aShape)
{
	// note that the object must be explicitly mentioned
	for (auto& currPnt : aShape.thePoints) {
		os << currPnt.x << "\t" << currPnt.y << endl;
	}
	return os;
}
