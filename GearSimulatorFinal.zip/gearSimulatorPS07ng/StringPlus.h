#pragma once

#include <string>
#include <sstream>

#include <msclr\marshal_cppstd.h>  //  needed for string conversions

//using namespace std;

class StringPlus {
public:
	// trims/removes leading spaces and tabs
	static std::string ltrim(std::string& inString) {
		auto firstNonSpace = inString.find_first_not_of(" \t");
		if (firstNonSpace == -1)
			return "";
		else
			return inString.substr(firstNonSpace);
	}

	// trims/removes trailing spaces and tabs
	static std::string rtrim(std::string& inString) {
		return inString.substr(0, inString.find_last_not_of(" \t") + 1);
	}

	// trims/removes both leading and trailing spaces and tabs
	static std::string trim(std::string& inString) {
		return ltrim(rtrim(inString));
	}

	// converts a CLR system string into a "regular C++ string"
	static std::string convertString(System::String^ aString) {
		msclr::interop::marshal_context context;
		std::string standardString = context.marshal_as<std::string>(aString);
		return standardString;
	}

	// takes a long string and returns a vector of strings by splitting along characters
	// in delim string. example delim = ",; \t"
	static std::vector<std::string> split(std::string str, std::string delim) {
		char* cstr = const_cast<char*>(str.c_str());
		char* current;
		std::vector<std::string> arr;
		current = strtok(cstr, delim.c_str());   // this is the "magic" tokenizer function 
		while (current != NULL) {
			arr.push_back(current);
			current = strtok(NULL, delim.c_str());
		}
		return arr;
	}

	static double roundToSigFigs(double value, int digits) {
		if (value == 0.) // cannot take log of zero
			return 0.;
		else {
			int logOfGiven = log10(fabs(value));
			int decimalPlaces = digits - 1 - logOfGiven; // may be "negative" decimal places
			
			// use the following to round to decimalPlaces
			double adjust = pow(10., decimalPlaces);
			return round(value * adjust) / adjust;  
		}
	}

	static System::String^ sigFigs(double value, int digits) {
		//System::String^ result = gcnew System::String("");
		double sigValue = roundToSigFigs(value, digits);
		return gcnew System::String(sigValue.ToString());
	}

};