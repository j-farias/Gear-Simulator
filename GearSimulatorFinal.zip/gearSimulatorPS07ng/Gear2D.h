/*			_____
		   /     \
		  /       \				Nestor Gomez
	,----<         >----.		Carnegie Mellon University
   /                     \		C++ for Engrs, 24-280
  /                       \		Prob Set 5. Due Thurs. Mar. 24, 2022
  \                       /
   \                     /
	>                   <		The Gear2D class models a two-dimensional
   /                     \		spur gear. The gear can generate involute
  /                       \		teeth and 
  \                       /		calculating the perimeter.
   \                     /
	`----<         >----'
		  \       /
		   \_____/
*/
#pragma once

#include <fstream>
#include "StringPlus.h"
#include "Shape2D.h"

class Gear2D {
	std::string gearID;
	float pitch;   // teeth per inch or mm of diameter (not along circumference of gear)
	int numbTeeth;
	float colorH, colorS, colorV;
	float minX, maxX, minY, maxY; // bounding box (for graphics mostly)
	Point2D location;
	float startAngle;  // deg, 0 @x-axis, CCW
	float prevAngle, currAngle;

	Shape2D* toothProfile;   // using pointer to make replacement easier
	float area, perimeter;   // area is useful to determine weight, perimeter not as much

	

	std::vector<Gear2D*> attachedTo;  
	std::vector<Gear2D*> meshedInto;  
	std::vector<Gear2D*> beltedTo;

public:

	// default constructor for the class. Initializes member variables  
	// (which now include dependent member variables minX, minY, maxX, and maxY, area, perimeter). 
	Gear2D();

	// additional constructor for the class. Takes a pre-created ifstream and uses it to read  
	// the properties of the gear. Also needs to instantiate any constituent objects  
	// and/or data structures 
	Gear2D(std::ifstream& input) : Gear2D() { readFile(input); };

	// destructor for gear. Removes connections to other gears
	~Gear2D();

	// takes a pre-created ifstream and uses it to read the properties of the gear. 
	// Also needs to instantiate any constituent objects and/or data structures 
	void readFile(std::ifstream& input);

	// writes gear parameters to given output stream 
	friend std::ostream& operator<<(std::ostream& os, const Gear2D& aGear);;

	// calculates and returns the pitch diameter of the gear 
	float getPitchDiam() const { return numbTeeth / pitch; };

	// sets all gear parameters to starting values 
	void reset();

	// return a point corresponding to the upper right corner of a bounding box for the shape  
	// (maximum X and maximum Y value of all points). 
	Point2D upperBoundingBox() { return { maxX, maxY }; };

	// return a point corresponding to the lower left corner of a bounding box for the shape  
	// (minimum X and minimum Y value of all points). 
	Point2D lowerBoundingBox() { return { minX, minY }; };

	//generates the geometry of the gear on the given graphic space, with given color and other  
	// parameters. Uses gear�s color unless a color is given 
	void paint(System::Drawing::Graphics^ g, System::Drawing::Color^ c = nullptr,
		bool showGearID = false, bool showTeethLabels = false, bool showCircles = false, bool fillGear = false,
		bool transparent = false);


	void paintLine(System::Drawing::Graphics^ g, float x1, float y1, float x2, float y2);


	// determines if the given coordinate point is within the gear. Used for graphical selection 
	bool isContained(Point2D coords) const;

	// some get and set functions

	std::string getID() const { return gearID; };
	void setID(std::string newID) { gearID = StringPlus::trim(newID); };
	std::string getDescription() const;

	float getCurrAngle() const { return currAngle; };
	void setCurrAngle(float newAngle) { currAngle = fmodf(newAngle, 360.); }
	float getStartAngle() const { return startAngle; };
	void setStartAngle(float newAngle) { startAngle = fmodf(newAngle, 360.); }
	float getArea() const { return area; };
	float getPerimeter() const { return perimeter; };
	float getPitch() const { return pitch; };
	int getNumbTeeth() const { return numbTeeth; };
	Point2D getLocation() const { return location; }
	void setLocation(Point2D newLoc) { 
		location = newLoc; 
		recalcGear(); 
	}
	void moveLocation(Point2D delta) { 
		location.x += delta.x;
		location.y += delta.y;
		recalcGear(); 
	}

	bool setPitch(float newPitch) {
		if (newPitch > 0.f) {
			pitch = newPitch;
			recalcGear();
			return true;
		}
		else
			return false;
	}

	bool setNumbTeeth(int newNumbTeeth) {
		if (newNumbTeeth > 2) {  // must have at least 3 teeth ???
			numbTeeth = newNumbTeeth;
			recalcGear();
			return true;
		}
		else
			return false;
	}

	void getColor(float& h, float& s, float& v) const {
		h = colorH; s = colorS; v = colorV;
	}
	System::Drawing::Color^ getColor() const;
	bool setColor(float h, float s, float v) {
		colorH = fmodf(h, 360.); colorS = s; colorV = v;
		return true;
	}

	// stuff added for PS06

	// determines if the two given gears can be meshed based on pitch compatibility
	bool isMeshableWith(const Gear2D& otherGear) const;
	
	// attempts to mesh this gear into otherGear, returns false if it cannot be done
	// note that this gear will need to be moved and rotated (its start angle changed) so that it can
	// properly mesh into otherGear. Note that otherGear also needs to have a link to this gear.
	// Be sure not to add gears twice (we�ll discuss in class)
	bool meshWith(Gear2D& otherGear);
	
	// attempts to attach this gear to otherGear, returns false if it cannot be done
	// note that this gear will need to be moved that its center matches that of otherGear
	// Note that otherGear also needs to have a link to this gear.
	// Be sure not to add gears twice (we�ll discuss in class)
	bool attachTo(Gear2D& otherGear);

	// attempts to belt this gear to otherGear, returns false if it cannot be done
	// note that gear will not be moved
	bool beltTo(Gear2D& otherGear);
	
	// remove otherGear from appropriate vector and ask the same of otherGear
	bool unmeshWith(Gear2D& otherGear);
	bool unattachTo(Gear2D& otherGear);
	bool unbeltWith(Gear2D& otherGear);
	
	// remove all gears from appropriate vector and ask the same 
	// of the other side of relationship
	bool unmeshAll();
	bool unattachAll();
	bool unbeltAll();

	

	// changes the current angle of the gear by the given amount (in degrees, CCW) 
	// the second parameter is used in simulation mode to assure the gear that requested 
	// this action is not itself asked to rotate (break circular logic) 
	void rotate(float angle, Gear2D* drivingGear = nullptr);

	void move(Point2D delta, Gear2D* drivingGear = nullptr);

	std::string listMeshedGears();
	std::string listAttachedGears();
	std::string listBeltedGears();

protected:
	// calculates all the dependent parameters of the gear, including toothProfile
	void recalcGear();

	// generates the involute shape of a gear tooth and stores it in a Shape2D object
	void generateToothProfile();

//	void addRotPntToProfile(float x, float y, float angle, int index);
};