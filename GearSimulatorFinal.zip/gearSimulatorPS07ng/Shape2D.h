/*			_____
		   /     \
		  /       \				Nestor Gomez
	,----<         >----.		Carnegie Mellon University
   /                     \		C++ for Engrs, 24-280
  /                       \		Prob Set 3. Due Thurs. Feb. 15, 2022
  \                       /
   \                     /
	>                   <		The Shape2D class models the geometry
   /                     \		of a two-dimensional shape. Allows
  /                       \		for addition of points and for
  \                       /		calculating the perimeter.
   \                     /
	`----<         >----'
		  \       /
		   \_____/
*/

#pragma once
#include <string>
#include <fstream>
#include <vector>

#include "Line2D.h"

class Shape2D {
private:
	std::vector<Point2D> thePoints; // stores the series of coordinate points
	float minX, maxX, minY, maxY;
	float shapeArea, shapePerim;

public:

	// default constructor for the class. Initializes member variables only.
	Shape2D();

	// additional constructor for the class. Takes a pre-created ifstream and uses it to read coordinate 
	// information for the shape. Note that the method�s parameter cannot be a string filename 
	// because the file may already be in the process of being read. The constructor needs to 
	// instantiate any constituent objects and/or data structures.
	Shape2D(std::ifstream& input);

	// adds a coordinate point such that the new point becomes the index-th point . For example, 
	// an index value of 3 will insert a point between the existing 2nd and 3rd points such that the 
	// new point becomes the new 3rd point. An index of 1 will insert the new point at the start 
	// of the shape and an index greater than the number of points will insert the new point as 
	// the last point. Function returns false only if the new point cannot be added for any reason. 
	bool addPoint(Point2D newPoint, int index);

	// creates a coordinate point with the given coordinates and inserts it into the path such that 
	// the new point becomes the index-th point. Otherwise similar to above.
	bool addPoint(float newX, float newY, int index);

	// creates a coordinate point between vertices index-1 and index and inserts it into the line 
	// segment at the given ratio. The ratio is a number greater than zero and less than 1. 
	// Note that, like above, the new point becomes the index-th point. Returns false if it cannot 
	// insert point (e.g., index is too large or too small, ratio value is inappropriate). 
	// [ A ratio close to zero will insert the new vertex near index-1; a ratio of 0.5 will insert 
	// the new vertex at the middle of the segment; and a ratio close to 1 will insert the new 
	// vertex near old index. ] 
	bool addPoint(int index, float ratio);

	// removes the indicated point from the shape. Function returns false only if the point 
	// cannot be removed for any reason.
	bool removePoint(int index);
	bool deletePoint(int index) { return removePoint(index); };  // sometimes I think it is "delete"

	// returns the length of the perimeter of the shape.
	float perimeter() { return shapePerim; };

	// returns the area the shape.
	// not required for PS02
	float area() { return shapeArea; };

	// used to output all the coordinates of a shape. This can be tricky, so we�ll discuss in lecture.
	friend std::ostream& operator<<(std::ostream& os, const Shape2D& aShape);

	// get coordinates of a point. The first point has index 1.
	// Returns {-INFINITY, -INFINITY} if index is invalid.
	Point2D getPoint(int index);

	// moves a point to new coordinates. The first point has index 1.
	// Returns false if index is invalid.
	bool movePoint(Point2D newCoords, int index);

	// changes the coordinates of a point by the given delta. The first point has index 1.
	// Returns false if index is invalid.
	bool movePointDelta(Point2D deltaCoords, int index);

	// returns the index of the first vertex (first vertex has indes 1) that is near the givenCoord.
	// Uses distance as bounding square instead of radius to reduce calculations.
	int getIndex(Point2D givenCoord, float dist = 0.1);

	// return a point corresponding to the upper right corner of a bounding box for the shape
	// (maximum X and maximum Y value of all points).
	Point2D upperBoundingBox() { return { maxX, maxY }; };

	// return a point corresponding to the lower left corner of a bounding box for the shape
	// (minimum X and minimum Y value of all points).
	Point2D lowerBoundingBox() { return { minX, minY }; };

	// returns the coordinates of center of the bounding rectangle that encompasses the shape.
	// Returns (-INFINITY, -INFINITY) if the path has no points.
	Point2D center() { return { (minX + maxX) / 2.f, (minY + maxY) / 2.f }; };

	// generates the geometry of the shape on the given graphic space, with given color and other
	// parameters (many of which have default values for now). This can be tricky, so we�ll develop it in lecture.
	void paint(System::Drawing::Graphics^ g,
		System::Drawing::Color c = System::Drawing::Color::Blue, bool showPoints = false, 
		float width = 0.f, bool fillShape = false, bool showLabel = false, bool openShape = false, bool transparent = false);

	// draws a "marker" on a given point
	void paintPnt(int index, System::Drawing::Graphics^ g,
		System::Drawing::Color c = System::Drawing::Color::Blue, bool showNumber = false,
		int pixelSize = 10, bool filled = false);

	// returns true if the coordinates of testPnt is contained inside the shape. If isInclusive is true,  
	// then a testPoint right on the shape outline itself is considered inside.  
	bool isContained(Point2D testPnt, bool isInclusive = true);

	// returns the y value by interpolating on x-values
	// assumes x-values are in increasing order
	float getYgivenX(float wantedX);

	// returns number of points
	int getNumbPoints() { return thePoints.size(); }

protected:
	// assure that dependent member variables are kept up-to-date.
	// called whenever there is change to the shape that may affect the dependent variables.
	void recalcShape();

	// determines if any of the edges of the shape intersects with any other edge
public:	bool selfIntersects();

};