#pragma once
#include <fstream>
//#include <unordered_map>

#include "StringPlus.h"
#include "Gear2D.h"
#include "ColorConverter.h"

namespace gearSimulatorPS07ng {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for GearEditor
	/// </summary>
	public ref class GearEditor : public System::Windows::Forms::Form
	{
	public:
		GearEditor(Gear2D* aGear) : GearEditor()
		{
			if (theGear != nullptr)
				delete theGear;
			theGear = aGear;
			updatePropertiesDisplay();
			resetView();
			//mainPanel->Refresh();
		}
		GearEditor(void)
		{
			if (theGear == nullptr)
				theGear = new Gear2D;

			InitializeComponent();
			labelCoords->Top = -100; // take labelCoords off the screen
			initializeHoverHelp();
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~GearEditor()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Panel^ mainPanel;
	private: System::Windows::Forms::Label^ feedbackLabel;
	private: System::Windows::Forms::Button^ buttonLoad;
	private: System::Windows::Forms::TextBox^ textBoxPitch;


	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ labelColor;

	protected:
		Gear2D* theGear = nullptr;
		int panX = 300, panY = 300, currX, currY;
		float zoomLevel = 1.f;
		bool mouseInPanel = false;
		float gearSize = 1.f;
		bool inRotationMode = false;
		Hashtable^ hoverResponses;

		//std::unordered_map<std::string, std::string> hoverResponses;

	private: System::Windows::Forms::Button^ buttonResetView;
	private: System::Windows::Forms::Label^ label3;

	private: System::Windows::Forms::Button^ buttonSave;
	private: System::Windows::Forms::Label^ label4;	private: System::Windows::Forms::HScrollBar^ hScrollBarLineWidth;
	private: System::Windows::Forms::CheckBox^ checkBoxShowGrid;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Label^ labelCoords;
	private: System::Windows::Forms::CheckBox^ checkBoxShowLabels;

	private: System::Windows::Forms::CheckBox^ checkBoxFillGear;
	private: System::Windows::Forms::CheckBox^ checkBoxShowToothLabels;

	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::Label^ label7;
	private: System::Windows::Forms::Label^ labelForPitchDiam;	private: System::Windows::Forms::Label^ labelForArea;
	private: System::Windows::Forms::Button^ buttonDelete;
	private: System::Windows::Forms::Button^ buttonInsert;
	private: System::Windows::Forms::CheckBox^ checkBoxShowCircles;
	private: System::Windows::Forms::TextBox^ textBoxNumbTeeth;
	private: System::Windows::Forms::Label^ label8;
	private: System::Windows::Forms::TextBox^ textBoxGearID;
	private: System::Windows::Forms::Label^ label9;
	private: System::Windows::Forms::TextBox^ textBoxLocation;
	private: System::Windows::Forms::Label^ label10;
	private: System::Windows::Forms::TextBox^ textBoxStartAngle;
	private: System::Windows::Forms::Label^ label11;
	private: System::Windows::Forms::TextBox^ textBoxCurrAngle;
	private: System::Windows::Forms::Label^ label12;
	private: System::Windows::Forms::Label^ label13;
	private: System::Windows::Forms::Label^ label14;
	private: System::Windows::Forms::CheckBox^ checkBoxShowScale;
	private: System::Windows::Forms::RadioButton^ radioButtonPolar;
	private: System::Windows::Forms::RadioButton^ radioButtonOrtho;
	private: System::Windows::Forms::CheckBox^ checkBoxTransparent;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->mainPanel = (gcnew System::Windows::Forms::Panel());
			this->labelCoords = (gcnew System::Windows::Forms::Label());
			this->feedbackLabel = (gcnew System::Windows::Forms::Label());
			this->buttonLoad = (gcnew System::Windows::Forms::Button());
			this->textBoxPitch = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->labelColor = (gcnew System::Windows::Forms::Label());
			this->buttonResetView = (gcnew System::Windows::Forms::Button());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->buttonSave = (gcnew System::Windows::Forms::Button());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->hScrollBarLineWidth = (gcnew System::Windows::Forms::HScrollBar());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->checkBoxShowGrid = (gcnew System::Windows::Forms::CheckBox());
			this->checkBoxShowLabels = (gcnew System::Windows::Forms::CheckBox());
			this->checkBoxFillGear = (gcnew System::Windows::Forms::CheckBox());
			this->checkBoxShowToothLabels = (gcnew System::Windows::Forms::CheckBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->labelForPitchDiam = (gcnew System::Windows::Forms::Label());
			this->labelForArea = (gcnew System::Windows::Forms::Label());
			this->checkBoxShowCircles = (gcnew System::Windows::Forms::CheckBox());
			this->textBoxNumbTeeth = (gcnew System::Windows::Forms::TextBox());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->textBoxGearID = (gcnew System::Windows::Forms::TextBox());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->textBoxLocation = (gcnew System::Windows::Forms::TextBox());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->textBoxStartAngle = (gcnew System::Windows::Forms::TextBox());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->textBoxCurrAngle = (gcnew System::Windows::Forms::TextBox());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->checkBoxShowScale = (gcnew System::Windows::Forms::CheckBox());
			this->radioButtonPolar = (gcnew System::Windows::Forms::RadioButton());
			this->radioButtonOrtho = (gcnew System::Windows::Forms::RadioButton());
			this->checkBoxTransparent = (gcnew System::Windows::Forms::CheckBox());
			this->mainPanel->SuspendLayout();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Elephant", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->ForeColor = System::Drawing::Color::Red;
			this->label1->Location = System::Drawing::Point(12, 9);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(150, 27);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Mesh-n-Load";
			// 
			// mainPanel
			// 
			this->mainPanel->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom)
				| System::Windows::Forms::AnchorStyles::Left)
				| System::Windows::Forms::AnchorStyles::Right));
			this->mainPanel->BackColor = System::Drawing::SystemColors::Window;
			this->mainPanel->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->mainPanel->Controls->Add(this->labelCoords);
			this->mainPanel->Location = System::Drawing::Point(129, 46);
			this->mainPanel->Name = L"mainPanel";
			this->mainPanel->Size = System::Drawing::Size(614, 394);
			this->mainPanel->TabIndex = 1;
			this->mainPanel->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &GearEditor::mainPanel_Paint);
			this->mainPanel->MouseDown += gcnew System::Windows::Forms::MouseEventHandler(this, &GearEditor::mainPanel_MouseDown);
			this->mainPanel->MouseEnter += gcnew System::EventHandler(this, &GearEditor::mainPanel_MouseEnter);
			this->mainPanel->MouseLeave += gcnew System::EventHandler(this, &GearEditor::mainPanel_MouseLeave);
			this->mainPanel->MouseMove += gcnew System::Windows::Forms::MouseEventHandler(this, &GearEditor::mainPanel_MouseMove);
			this->mainPanel->MouseUp += gcnew System::Windows::Forms::MouseEventHandler(this, &GearEditor::mainPanel_MouseUp);
			// 
			// labelCoords
			// 
			this->labelCoords->AutoSize = true;
			this->labelCoords->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->labelCoords->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->labelCoords->Location = System::Drawing::Point(115, 25);
			this->labelCoords->Name = L"labelCoords";
			this->labelCoords->Size = System::Drawing::Size(85, 15);
			this->labelCoords->TabIndex = 0;
			this->labelCoords->Text = L"Used for Coords";
			// 
			// feedbackLabel
			// 
			this->feedbackLabel->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Left));
			this->feedbackLabel->AutoSize = true;
			this->feedbackLabel->Location = System::Drawing::Point(133, 447);
			this->feedbackLabel->Name = L"feedbackLabel";
			this->feedbackLabel->Size = System::Drawing::Size(22, 13);
			this->feedbackLabel->TabIndex = 2;
			this->feedbackLabel->Text = L"- - -";
			// 
			// buttonLoad
			// 
			this->buttonLoad->Location = System::Drawing::Point(6, 63);
			this->buttonLoad->Name = L"buttonLoad";
			this->buttonLoad->Size = System::Drawing::Size(59, 33);
			this->buttonLoad->TabIndex = 1;
			this->buttonLoad->Text = L"Load";
			this->buttonLoad->UseVisualStyleBackColor = true;
			this->buttonLoad->Click += gcnew System::EventHandler(this, &GearEditor::buttonLoad_Click);
			this->buttonLoad->MouseHover += gcnew System::EventHandler(this, &GearEditor::helpFeedback_MouseHover);
			// 
			// textBoxPitch
			// 
			this->textBoxPitch->Location = System::Drawing::Point(54, 159);
			this->textBoxPitch->Name = L"textBoxPitch";
			this->textBoxPitch->Size = System::Drawing::Size(68, 20);
			this->textBoxPitch->TabIndex = 4;
			this->textBoxPitch->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &GearEditor::textBoxPitch_KeyDown);
			this->textBoxPitch->MouseHover += gcnew System::EventHandler(this, &GearEditor::helpFeedback_MouseHover);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(22, 163);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(31, 13);
			this->label2->TabIndex = 5;
			this->label2->Text = L"Pitch";
			this->label2->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
			// 
			// labelColor
			// 
			this->labelColor->BackColor = System::Drawing::Color::Red;
			this->labelColor->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->labelColor->ForeColor = System::Drawing::Color::White;
			this->labelColor->Location = System::Drawing::Point(6, 407);
			this->labelColor->Name = L"labelColor";
			this->labelColor->Size = System::Drawing::Size(115, 18);
			this->labelColor->TabIndex = 6;
			this->labelColor->Text = L"Change Color";
			this->labelColor->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			this->labelColor->Click += gcnew System::EventHandler(this, &GearEditor::labelColor_Click);
			// 
			// buttonResetView
			// 
			this->buttonResetView->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->buttonResetView->Location = System::Drawing::Point(698, 6);
			this->buttonResetView->Name = L"buttonResetView";
			this->buttonResetView->RightToLeft = System::Windows::Forms::RightToLeft::Yes;
			this->buttonResetView->Size = System::Drawing::Size(45, 38);
			this->buttonResetView->TabIndex = 7;
			this->buttonResetView->Text = L"Reset View";
			this->buttonResetView->UseVisualStyleBackColor = true;
			this->buttonResetView->Click += gcnew System::EventHandler(this, &GearEditor::buttonResetView_Click);
			this->buttonResetView->MouseHover += gcnew System::EventHandler(this, &GearEditor::helpFeedback_MouseHover);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(18, 295);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(29, 13);
			this->label3->TabIndex = 8;
			this->label3->Text = L"Area";
			this->label3->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
			// 
			// buttonSave
			// 
			this->buttonSave->Location = System::Drawing::Point(66, 63);
			this->buttonSave->Name = L"buttonSave";
			this->buttonSave->Size = System::Drawing::Size(59, 33);
			this->buttonSave->TabIndex = 3;
			this->buttonSave->Text = L"Save";
			this->buttonSave->UseVisualStyleBackColor = true;
			this->buttonSave->Click += gcnew System::EventHandler(this, &GearEditor::buttonSave_Click);
			this->buttonSave->MouseHover += gcnew System::EventHandler(this, &GearEditor::helpFeedback_MouseHover);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(-1, 273);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(58, 13);
			this->label4->TabIndex = 8;
			this->label4->Text = L"Pitch Diam";
			this->label4->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
			// 
			// hScrollBarLineWidth
			// 
			this->hScrollBarLineWidth->Location = System::Drawing::Point(8, 384);
			this->hScrollBarLineWidth->Name = L"hScrollBarLineWidth";
			this->hScrollBarLineWidth->Size = System::Drawing::Size(112, 14);
			this->hScrollBarLineWidth->TabIndex = 10;
			this->hScrollBarLineWidth->ValueChanged += gcnew System::EventHandler(this, &GearEditor::hScrollBarLineWidth_ValueChanged);
			this->hScrollBarLineWidth->MouseHover += gcnew System::EventHandler(this, &GearEditor::hScrollBarLineWidth_MouseHover);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(9, 369);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(58, 13);
			this->label5->TabIndex = 11;
			this->label5->Text = L"Line Width";
			// 
			// checkBoxShowGrid
			// 
			this->checkBoxShowGrid->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->checkBoxShowGrid->AutoSize = true;
			this->checkBoxShowGrid->Location = System::Drawing::Point(372, 6);
			this->checkBoxShowGrid->Name = L"checkBoxShowGrid";
			this->checkBoxShowGrid->Size = System::Drawing::Size(75, 17);
			this->checkBoxShowGrid->TabIndex = 12;
			this->checkBoxShowGrid->Text = L"Show Grid";
			this->checkBoxShowGrid->UseVisualStyleBackColor = true;
			this->checkBoxShowGrid->CheckedChanged += gcnew System::EventHandler(this, &GearEditor::checkBoxShowGrid_CheckedChanged);
			// 
			// checkBoxShowLabels
			// 
			this->checkBoxShowLabels->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->checkBoxShowLabels->AutoSize = true;
			this->checkBoxShowLabels->Location = System::Drawing::Point(591, 6);
			this->checkBoxShowLabels->Name = L"checkBoxShowLabels";
			this->checkBoxShowLabels->Size = System::Drawing::Size(57, 17);
			this->checkBoxShowLabels->TabIndex = 12;
			this->checkBoxShowLabels->Text = L"Labels";
			this->checkBoxShowLabels->UseVisualStyleBackColor = true;
			this->checkBoxShowLabels->CheckedChanged += gcnew System::EventHandler(this, &GearEditor::checkBoxShowLabels_CheckedChanged);
			// 
			// checkBoxFillGear
			// 
			this->checkBoxFillGear->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->checkBoxFillGear->AutoSize = true;
			this->checkBoxFillGear->Location = System::Drawing::Point(492, 6);
			this->checkBoxFillGear->Name = L"checkBoxFillGear";
			this->checkBoxFillGear->Size = System::Drawing::Size(64, 17);
			this->checkBoxFillGear->TabIndex = 12;
			this->checkBoxFillGear->Text = L"Fill Gear";
			this->checkBoxFillGear->UseVisualStyleBackColor = true;
			this->checkBoxFillGear->CheckedChanged += gcnew System::EventHandler(this, &GearEditor::checkBoxFillGear_CheckedChanged);
			// 
			// checkBoxShowToothLabels
			// 
			this->checkBoxShowToothLabels->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->checkBoxShowToothLabels->AutoSize = true;
			this->checkBoxShowToothLabels->Enabled = false;
			this->checkBoxShowToothLabels->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 6.75F, System::Drawing::FontStyle::Regular,
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->checkBoxShowToothLabels->Location = System::Drawing::Point(649, 23);
			this->checkBoxShowToothLabels->Name = L"checkBoxShowToothLabels";
			this->checkBoxShowToothLabels->Size = System::Drawing::Size(47, 16);
			this->checkBoxShowToothLabels->TabIndex = 12;
			this->checkBoxShowToothLabels->Text = L"Teeth";
			this->checkBoxShowToothLabels->UseVisualStyleBackColor = true;
			this->checkBoxShowToothLabels->CheckedChanged += gcnew System::EventHandler(this, &GearEditor::checkBox_JustRefresh);
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(5, 443);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(54, 13);
			this->label6->TabIndex = 8;
			this->label6->Text = L"for coords";
			this->label6->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(3, 430);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(73, 13);
			this->label7->TabIndex = 8;
			this->label7->Text = L"Shft+LeftClick";
			this->label7->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
			// 
			// labelForPitchDiam
			// 
			this->labelForPitchDiam->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->labelForPitchDiam->Location = System::Drawing::Point(57, 269);
			this->labelForPitchDiam->Name = L"labelForPitchDiam";
			this->labelForPitchDiam->Size = System::Drawing::Size(63, 21);
			this->labelForPitchDiam->TabIndex = 8;
			this->labelForPitchDiam->Text = L"- - -";
			this->labelForPitchDiam->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			this->labelForPitchDiam->MouseHover += gcnew System::EventHandler(this, &GearEditor::helpFeedback_MouseHover);
			// 
			// labelForArea
			// 
			this->labelForArea->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->labelForArea->Location = System::Drawing::Point(56, 295);
			this->labelForArea->Name = L"labelForArea";
			this->labelForArea->Size = System::Drawing::Size(64, 21);
			this->labelForArea->TabIndex = 8;
			this->labelForArea->Text = L"- - -";
			this->labelForArea->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			this->labelForArea->MouseHover += gcnew System::EventHandler(this, &GearEditor::helpFeedback_MouseHover);
			// 
			// checkBoxShowCircles
			// 
			this->checkBoxShowCircles->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->checkBoxShowCircles->AutoSize = true;
			this->checkBoxShowCircles->Enabled = false;
			this->checkBoxShowCircles->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 6.75F, System::Drawing::FontStyle::Regular,
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->checkBoxShowCircles->Location = System::Drawing::Point(595, 23);
			this->checkBoxShowCircles->Name = L"checkBoxShowCircles";
			this->checkBoxShowCircles->Size = System::Drawing::Size(53, 16);
			this->checkBoxShowCircles->TabIndex = 12;
			this->checkBoxShowCircles->Text = L"Circles";
			this->checkBoxShowCircles->UseVisualStyleBackColor = true;
			this->checkBoxShowCircles->CheckedChanged += gcnew System::EventHandler(this, &GearEditor::checkBox_JustRefresh);
			// 
			// textBoxNumbTeeth
			// 
			this->textBoxNumbTeeth->Location = System::Drawing::Point(54, 133);
			this->textBoxNumbTeeth->Name = L"textBoxNumbTeeth";
			this->textBoxNumbTeeth->Size = System::Drawing::Size(68, 20);
			this->textBoxNumbTeeth->TabIndex = 4;
			this->textBoxNumbTeeth->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &GearEditor::textBoxNumbTeeth_KeyDown);
			this->textBoxNumbTeeth->MouseHover += gcnew System::EventHandler(this, &GearEditor::helpFeedback_MouseHover);
			// 
			// label8
			// 
			this->label8->Location = System::Drawing::Point(7, 121);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(46, 42);
			this->label8->TabIndex = 5;
			this->label8->Text = L"Numb Teeth";
			this->label8->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
			// 
			// textBoxGearID
			// 
			this->textBoxGearID->Location = System::Drawing::Point(53, 108);
			this->textBoxGearID->Name = L"textBoxGearID";
			this->textBoxGearID->Size = System::Drawing::Size(69, 20);
			this->textBoxGearID->TabIndex = 4;
			this->textBoxGearID->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &GearEditor::textBoxGearID_KeyDown);
			this->textBoxGearID->MouseHover += gcnew System::EventHandler(this, &GearEditor::helpFeedback_MouseHover);
			// 
			// label9
			// 
			this->label9->Location = System::Drawing::Point(12, 106);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(37, 26);
			this->label9->TabIndex = 5;
			this->label9->Text = L"ID";
			this->label9->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
			// 
			// textBoxLocation
			// 
			this->textBoxLocation->Location = System::Drawing::Point(54, 185);
			this->textBoxLocation->Name = L"textBoxLocation";
			this->textBoxLocation->Size = System::Drawing::Size(68, 20);
			this->textBoxLocation->TabIndex = 4;
			this->textBoxLocation->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &GearEditor::textBoxLocation_KeyDown);
			this->textBoxLocation->MouseHover += gcnew System::EventHandler(this, &GearEditor::helpFeedback_MouseHover);
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Location = System::Drawing::Point(5, 188);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(48, 13);
			this->label10->TabIndex = 5;
			this->label10->Text = L"Location";
			this->label10->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
			// 
			// textBoxStartAngle
			// 
			this->textBoxStartAngle->Location = System::Drawing::Point(54, 209);
			this->textBoxStartAngle->Name = L"textBoxStartAngle";
			this->textBoxStartAngle->Size = System::Drawing::Size(44, 20);
			this->textBoxStartAngle->TabIndex = 4;
			this->textBoxStartAngle->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &GearEditor::textBoxStartAngle_KeyDown);
			this->textBoxStartAngle->MouseHover += gcnew System::EventHandler(this, &GearEditor::helpFeedback_MouseHover);
			// 
			// label11
			// 
			this->label11->Location = System::Drawing::Point(3, 206);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(52, 26);
			this->label11->TabIndex = 5;
			this->label11->Text = L"Start Angle";
			this->label11->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
			// 
			// textBoxCurrAngle
			// 
			this->textBoxCurrAngle->Enabled = false;
			this->textBoxCurrAngle->Location = System::Drawing::Point(54, 235);
			this->textBoxCurrAngle->Name = L"textBoxCurrAngle";
			this->textBoxCurrAngle->Size = System::Drawing::Size(44, 20);
			this->textBoxCurrAngle->TabIndex = 4;
			this->textBoxCurrAngle->MouseHover += gcnew System::EventHandler(this, &GearEditor::helpFeedback_MouseHover);
			// 
			// label12
			// 
			this->label12->ForeColor = System::Drawing::SystemColors::ControlDark;
			this->label12->Location = System::Drawing::Point(1, 235);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(52, 26);
			this->label12->TabIndex = 5;
			this->label12->Text = L"Curr Angle";
			this->label12->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->Location = System::Drawing::Point(100, 212);
			this->label13->Name = L"label13";
			this->label13->Size = System::Drawing::Size(25, 13);
			this->label13->TabIndex = 8;
			this->label13->Text = L"deg";
			this->label13->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->ForeColor = System::Drawing::SystemColors::ControlDark;
			this->label14->Location = System::Drawing::Point(98, 238);
			this->label14->Name = L"label14";
			this->label14->Size = System::Drawing::Size(25, 13);
			this->label14->TabIndex = 8;
			this->label14->Text = L"deg";
			this->label14->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
			// 
			// checkBoxShowScale
			// 
			this->checkBoxShowScale->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->checkBoxShowScale->AutoSize = true;
			this->checkBoxShowScale->Checked = true;
			this->checkBoxShowScale->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBoxShowScale->Location = System::Drawing::Point(295, 6);
			this->checkBoxShowScale->Name = L"checkBoxShowScale";
			this->checkBoxShowScale->Size = System::Drawing::Size(53, 17);
			this->checkBoxShowScale->TabIndex = 12;
			this->checkBoxShowScale->Text = L"Scale";
			this->checkBoxShowScale->UseVisualStyleBackColor = true;
			this->checkBoxShowScale->CheckedChanged += gcnew System::EventHandler(this, &GearEditor::checkBox_JustRefresh);
			// 
			// radioButtonPolar
			// 
			this->radioButtonPolar->AutoSize = true;
			this->radioButtonPolar->Checked = true;
			this->radioButtonPolar->Cursor = System::Windows::Forms::Cursors::Default;
			this->radioButtonPolar->Enabled = false;
			this->radioButtonPolar->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 6.75F, System::Drawing::FontStyle::Regular,
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->radioButtonPolar->Location = System::Drawing::Point(378, 23);
			this->radioButtonPolar->Name = L"radioButtonPolar";
			this->radioButtonPolar->Size = System::Drawing::Size(44, 16);
			this->radioButtonPolar->TabIndex = 13;
			this->radioButtonPolar->TabStop = true;
			this->radioButtonPolar->Text = L"Polar";
			this->radioButtonPolar->UseVisualStyleBackColor = true;
			this->radioButtonPolar->CheckedChanged += gcnew System::EventHandler(this, &GearEditor::checkBox_JustRefresh);
			// 
			// radioButtonOrtho
			// 
			this->radioButtonOrtho->AutoSize = true;
			this->radioButtonOrtho->Enabled = false;
			this->radioButtonOrtho->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 6.75F, System::Drawing::FontStyle::Regular,
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->radioButtonOrtho->Location = System::Drawing::Point(426, 23);
			this->radioButtonOrtho->Name = L"radioButtonOrtho";
			this->radioButtonOrtho->Size = System::Drawing::Size(46, 16);
			this->radioButtonOrtho->TabIndex = 14;
			this->radioButtonOrtho->Text = L"Ortho";
			this->radioButtonOrtho->UseVisualStyleBackColor = true;
			this->radioButtonOrtho->CheckedChanged += gcnew System::EventHandler(this, &GearEditor::checkBox_JustRefresh);
			// 
			// checkBoxTransparent
			// 
			this->checkBoxTransparent->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->checkBoxTransparent->AutoSize = true;
			this->checkBoxTransparent->Checked = true;
			this->checkBoxTransparent->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBoxTransparent->Enabled = false;
			this->checkBoxTransparent->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 6.75F, System::Drawing::FontStyle::Regular,
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->checkBoxTransparent->Location = System::Drawing::Point(504, 24);
			this->checkBoxTransparent->Name = L"checkBoxTransparent";
			this->checkBoxTransparent->Size = System::Drawing::Size(73, 16);
			this->checkBoxTransparent->TabIndex = 12;
			this->checkBoxTransparent->Text = L"Transparent";
			this->checkBoxTransparent->UseVisualStyleBackColor = true;
			this->checkBoxTransparent->CheckedChanged += gcnew System::EventHandler(this, &GearEditor::checkBox_JustRefresh);
			// 
			// GearEditor
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(255)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->ClientSize = System::Drawing::Size(747, 465);
			this->Controls->Add(this->radioButtonOrtho);
			this->Controls->Add(this->radioButtonPolar);
			this->Controls->Add(this->checkBoxTransparent);
			this->Controls->Add(this->checkBoxShowScale);
			this->Controls->Add(this->checkBoxFillGear);
			this->Controls->Add(this->checkBoxShowCircles);
			this->Controls->Add(this->checkBoxShowToothLabels);
			this->Controls->Add(this->checkBoxShowLabels);
			this->Controls->Add(this->checkBoxShowGrid);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->hScrollBarLineWidth);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->labelForArea);
			this->Controls->Add(this->labelForPitchDiam);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label14);
			this->Controls->Add(this->label13);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->buttonResetView);
			this->Controls->Add(this->labelColor);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->label12);
			this->Controls->Add(this->label11);
			this->Controls->Add(this->label10);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->textBoxGearID);
			this->Controls->Add(this->textBoxNumbTeeth);
			this->Controls->Add(this->textBoxCurrAngle);
			this->Controls->Add(this->textBoxStartAngle);
			this->Controls->Add(this->textBoxLocation);
			this->Controls->Add(this->textBoxPitch);
			this->Controls->Add(this->buttonSave);
			this->Controls->Add(this->buttonLoad);
			this->Controls->Add(this->feedbackLabel);
			this->Controls->Add(this->mainPanel);
			this->Controls->Add(this->label1);
			this->Name = L"GearEditor";
			this->Text = L" ";
			this->MouseWheel += gcnew System::Windows::Forms::MouseEventHandler(this, &GearEditor::GearEditor_MouseWheel);
			this->Resize += gcnew System::EventHandler(this, &GearEditor::GearEditor_Resize);
			this->mainPanel->ResumeLayout(false);
			this->mainPanel->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void mainPanel_Paint(System::Object^ sender, System::Windows::Forms::PaintEventArgs^ e) {
		auto g = e->Graphics;
		g->SmoothingMode = System::Drawing::Drawing2D::SmoothingMode::AntiAlias;

		g->TranslateTransform(panX, panY);
		g->ScaleTransform(zoomLevel, -zoomLevel);

		if (checkBoxShowGrid->Checked)
			if (radioButtonOrtho->Checked)
				drawOrthoGrid(g);
			else
				drawPolarGrid(g);

		if (theGear != nullptr) {
			theGear->paint(g, labelColor->BackColor, checkBoxShowLabels->Checked,
				checkBoxShowToothLabels->Checked && checkBoxShowLabels->Checked,
				checkBoxShowCircles->Checked && checkBoxShowLabels->Checked,
				checkBoxFillGear->Checked, checkBoxTransparent->Checked);
		}

		if (checkBoxShowScale->Checked) {
			drawScale(g);
		}
	}

	private: System::Void GearEditor_Resize(System::Object^ sender, System::EventArgs^ e) {
		mainPanel->Refresh();
	}
	private: System::Void buttonLoad_Click(System::Object^ sender, System::EventArgs^ e) {
		IO::Stream^ myStream; // needed to capture the results
		OpenFileDialog^ theDialog = gcnew OpenFileDialog;

		theDialog->InitialDirectory = ".";  // current folder
		theDialog->Filter = "Gear files (*.gear)|*.gear|All files (*.*)|*.*";
		theDialog->FilterIndex = 1;  // will show only linkage files, but user can choose to show all files
		theDialog->Multiselect = false;  // this is the default, but nice to know
		theDialog->RestoreDirectory = true; // will remember last directory/folder used

		// actually open the file dialog and get the name of the file user wants
		if (theDialog->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
			// user did not press cancel button nor closed the dialog
			// create filestream for the file
			if ((myStream = theDialog->OpenFile()) != nullptr)
			{
				feedbackLabel->Text = theDialog->FileName + " is opening";

				myStream->Close();  // don't need it anymore
				std::ifstream inFile;
				inFile.open(StringPlus::convertString(theDialog->FileName)); // needs StringPlus.h

				if (inFile.is_open()) {
					// do whatever you need with inFile (like use it to create a gear, maybe)

					//// if there is a gear already, clear the memory (instead of just abandon it)
					//if (theGear != nullptr)
					//	delete theGear;  // follow the pointer and "release" the memory

					//theGear = new Gear2D(inFile); // allocate new memory and let my variable point to it

					// now that my gear editing is a sub-task of GearTrain editing, just over-write theGear
					theGear->readFile(inFile);

					inFile.close();

					updatePropertiesDisplay();
					resetView();

					//mainPanel->Refresh();  // not needed since resetView() does it
				}
				else {
					// provide feedback that you were unable to open file ???
					feedbackLabel->Text = " ERROR: Could not open " + theDialog->FileName;
				}
			}
		}
	}
	private: System::Void buttonSave_Click(System::Object^ sender, System::EventArgs^ e) {
		if (theGear != nullptr) {
			IO::Stream^ myStream; // needed to capture the results
			SaveFileDialog^ theDialog = gcnew SaveFileDialog;

			theDialog->InitialDirectory = ".";  // current folder
			theDialog->Filter = "Gear files (*.gear)|*.gear|All files (*.*)|*.*";
			theDialog->FilterIndex = 1;  // will show only linkage files, but user can choose to show all files
			theDialog->RestoreDirectory = true; // will remember last directory/folder used

			// actually open the file dialog and get the name of the file user wants
			if (theDialog->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
				// user did not press cancel button nor closed the dialog
				// create filestream for the file
				if ((myStream = theDialog->OpenFile()) != nullptr)
				{
					feedbackLabel->Text = theDialog->FileName + " is opening";

					myStream->Close();  // don't need it anymore
					std::ofstream outFile;
					outFile.open(StringPlus::convertString(theDialog->FileName)); // needs StringPlus.h

					if (outFile.is_open()) {
						// do whatever you need with outFile (like use it to output a gear, maybe)
						outFile << *theGear; // follow the pointer then output

						outFile.close();

					}
					else {
						// provide feedback that you were unable to open file ???
						feedbackLabel->Text = " ERROR: Could not save to " + theDialog->FileName;
					}
				}
			}
		}
		else {
			feedbackLabel->Text = " ERROR: There is nothing to save.";
		}
	}

	private: System::Void labelColor_Click(System::Object^ sender, System::EventArgs^ e) {
		ColorDialog^ myDialog = gcnew ColorDialog();

		myDialog->FullOpen = true;
		myDialog->ShowDialog();

		// get color from dialog and assign it to labelColor
		labelColor->BackColor = myDialog->Color;
		mainPanel->Refresh();

		// change the color of the gear itself
		if (theGear != nullptr) {
			float h, s, v;
			ColorNG::colorToHSV(myDialog->Color, h, s, v); // h, s, and v are output parameters
			theGear->setColor(h, s, v);
		}
	}

	private: void resetView() {
		if (theGear != nullptr) {
			Point2D lowerBound = theGear->lowerBoundingBox();
			Point2D upperBound = theGear->upperBoundingBox();
			if (lowerBound.x > -INFINITY && upperBound.x > -INFINITY) {
				float gearHeight = upperBound.y - lowerBound.y;
				float gearWidth = upperBound.x - lowerBound.x;

				// don't want height or width to be zero since we'll used them to divide
				gearHeight = max(0.01, gearHeight);  // may need to #include <algorithm> to use min and max
				gearWidth = max(0.01, gearWidth);    // may need to #include <algorithm> to use min and max

				gearSize = max(gearHeight, gearWidth); // for calculating line width

				float heightRatio = mainPanel->Height / gearHeight;
				float widthRatio = mainPanel->Width / gearWidth;

				float borderSpaceRatio = 0.85;  // value of 1.0 will leave no white space around gear
				zoomLevel = min(heightRatio, widthRatio) * borderSpaceRatio;  // may need to #include <algorithm> to use min and max

				panY = mainPanel->Height / 2;
				panX = mainPanel->Width / 2;
				panX += -(upperBound.x + lowerBound.x) / 2. * zoomLevel;
				panY += (upperBound.y + lowerBound.y) / 2. * zoomLevel;
				// note that panY adjustment is not negative because panY is applied before scaling

				mainPanel->Refresh();
			}
		}
	}

	private: void resetLocationBox() {  // needed because I may set location graphically
		if (theGear != nullptr) {
			auto locPnt = theGear->getLocation();
			textBoxLocation->Text = StringPlus::sigFigs(locPnt.x, 4) + ", " + StringPlus::sigFigs(locPnt.y, 4);
		}
	}

	private: void resetAngleBoxes() { // needed because I may set graphically
		if (theGear != nullptr) {
			auto result = theGear->getStartAngle();
			textBoxStartAngle->Text = StringPlus::sigFigs(result, 4);
			textBoxCurrAngle->Text = StringPlus::sigFigs(result, 4);
		}
	}

	private: System::Void textBoxGearID_KeyDown(System::Object^ sender, System::Windows::Forms::KeyEventArgs^ e) {
		if (theGear != nullptr && e->KeyCode == Keys::Enter) {
			e->SuppressKeyPress = true;

			theGear->setID(StringPlus::convertString(textBoxGearID->Text));
			mainPanel->Refresh();
		}
	}
	private: System::Void textBoxPitch_KeyDown(System::Object^ sender, System::Windows::Forms::KeyEventArgs^ e) {
		if (theGear != nullptr && e->KeyCode == Keys::Enter) {
			e->SuppressKeyPress = true;
			auto newPitch = getFloatFromBox(textBoxPitch);
			if (newPitch != -INFINITY) {
				theGear->setPitch(newPitch);
				//mainPanel->Refresh();
				resetView();
				updatePropertiesDisplay();
			}
		}
	}
	private: System::Void textBoxNumbTeeth_KeyDown(System::Object^ sender, System::Windows::Forms::KeyEventArgs^ e) {
		if (theGear != nullptr && e->KeyCode == Keys::Enter) {
			e->SuppressKeyPress = true;
			auto newNumbTeeth = getFloatFromBox(textBoxNumbTeeth);
			if (newNumbTeeth != -MININT) {
				theGear->setNumbTeeth(newNumbTeeth);
				//mainPanel->Refresh();
				resetView();
				updatePropertiesDisplay();
			}
		}
	}
	private: System::Void textBoxLocation_KeyDown(System::Object^ sender, System::Windows::Forms::KeyEventArgs^ e) {
		if (theGear != nullptr && e->KeyCode == Keys::Enter) {
			e->SuppressKeyPress = true;
			auto newCoords = getCoordsFromBox(textBoxLocation);
			if (newCoords.x != -INFINITY) {
				theGear->setLocation(newCoords);
				//mainPanel->Refresh();
				resetView();
			}
		}
	}

	private: System::Void textBoxStartAngle_KeyDown(System::Object^ sender, System::Windows::Forms::KeyEventArgs^ e) {
		if (theGear != nullptr && e->KeyCode == Keys::Enter) {
			e->SuppressKeyPress = true;
			auto newStartAngle = getFloatFromBox(textBoxStartAngle);
			if (newStartAngle != -MININT) {
				theGear->setStartAngle(newStartAngle);
				theGear->reset();
				mainPanel->Refresh();
				resetAngleBoxes();
			}
		}
	}

	private: Point2D getCoordsFromBox(TextBox^ currBox) {
		// use try-catch block to check that coord values make sense
		String^ boxName = currBox->Name;
		try {
			int commaLoc = currBox->Text->IndexOf(",");
			float newX = Convert::ToSingle(currBox->Text->Substring(0, commaLoc));
			float newY = Convert::ToSingle(currBox->Text->Substring(commaLoc + 1));
			return { newX, newY };
		}
		catch (Exception^ e) {
			MessageBox::Show(e->Message + "\n\nUnable to get coordinates from " + boxName);
			currBox->Focus();
			return { -INFINITY, -INFINITY };
		}
	}

	private: System::Void buttonResetView_Click(System::Object^ sender, System::EventArgs^ e) {
		resetView();
	}

	private: System::Void mainPanel_MouseDown(System::Object^ sender, System::Windows::Forms::MouseEventArgs^ e) {
		// this if is part of panning (sets the initial mousewheel click position)
		if (e->Button == System::Windows::Forms::MouseButtons::Middle
			|| e->Button == System::Windows::Forms::MouseButtons::Left) {
			currX = e->X;
			currY = e->Y;
		}
		if (e->Button == System::Windows::Forms::MouseButtons::Left) {
			if (Control::ModifierKeys == Keys::Shift) {
				// show coords on popup yellow window
				makeCoordsYellow();
				Point2D clickedPnt;
				if (theGear != nullptr) {
					clickedPnt = getWorldCoords(e->X, e->Y);
					if (theGear->isContained(clickedPnt))
						makeCoordsOrange();
				}
				else
					clickedPnt = { e->X * 1.f, e->Y * 1.f }; // need to convert to float

				labelCoords->Text = StringPlus::sigFigs(clickedPnt.x, 4) + ", " + StringPlus::sigFigs(clickedPnt.y, 4);
				labelCoords->Top = e->Y + 10 /*+ mainPanel->Top*/;     // no need for mainPanel adjustment now that labelCoords is inside mainPanel
				labelCoords->Left = e->X + 15 /*+ mainPanel->Left*/;
			}
			else if (theGear != nullptr) {
				// if click is on the gear, start rotation process
				Point2D clickPnt = getWorldCoords(e->X, e->Y);
				if (theGear->isContained(clickPnt))
					inRotationMode = true;
			}
		}

	}
	private: System::Void mainPanel_MouseMove(System::Object^ sender, System::Windows::Forms::MouseEventArgs^ e) {
		// this function allows panning by pressing down on mousewheel and dragging
		// essentially, we adjust panning by however much the mouse is moved
		if (e->Button == System::Windows::Forms::MouseButtons::Middle) {
			// pan the screen
			panX += (e->X - currX);
			panY += (e->Y - currY);
			mainPanel->Refresh();  // this will "repaint" the main panel
			currX = e->X; currY = e->Y; // need to constantly update to allow drag
		}
		else if (e->Button == System::Windows::Forms::MouseButtons::Left && inRotationMode) {
			// change startAngle
			Point2D prevWorldPnt = getWorldCoords(currX, currY);
			Point2D currWorldPnt = getWorldCoords(e->X, e->Y);

			float prevAngle = Line2D::getAngle(theGear->getLocation(), prevWorldPnt);
			float currAngle = Line2D::getAngle(theGear->getLocation(), currWorldPnt);
			float deltaAngle = /*roundf*/(currAngle - prevAngle);

			theGear->setStartAngle(theGear->getStartAngle() + deltaAngle);
			theGear->reset();
			mainPanel->Refresh();
			updatePropertiesDisplay();

			currX = e->X; currY = e->Y; // need to constantly update to allow drag

		}
	}
	private: System::Void mainPanel_MouseEnter(System::Object^ sender, System::EventArgs^ e) {
		mouseInPanel = true;
	}
	private: System::Void mainPanel_MouseLeave(System::Object^ sender, System::EventArgs^ e) {
		mouseInPanel = false;
	}
	private: void GearEditor_MouseWheel(Object^ sender, System::Windows::Forms::MouseEventArgs^ e)
	{
		// panel does not take a mousewheel event, so we must handle it at the the level of the form
		// but only if the mouse pointer is inside the panel
		if (mouseInPanel) {

			float oldZoom = zoomLevel; // will need to remember this when resetting panX and panY

			float zoomStep = 1.2f;  // change as needed for more effect per wheel roll
			//e->Delta * SystemInformation::MouseWheelScrollLines / 120
			if (e->Delta < 0) // down roll so zoom out
				zoomLevel = zoomLevel / zoomStep;
			else   // up rool so zoom in
				zoomLevel = zoomLevel * zoomStep;

			// get actual location of pointer inside the panel (as opposed to the form itself)
			int adjustedX = e->X - mainPanel->Location.X - mainPanel->Margin.Left;
			int adjustedY = e->Y - mainPanel->Location.Y - mainPanel->Margin.Top;


			// reset panX and panY such that the coords under the mouse pointer are unchanged
			// i.e., we can zoom in/out on a specific point
			panX = (int)round((adjustedX * (oldZoom - zoomLevel)
				+ panX * zoomLevel) / oldZoom);
			panY = (int)round((adjustedY * (oldZoom - zoomLevel)
				+ panY * zoomLevel) / oldZoom);

			mainPanel->Refresh();

		}
	}
	private: System::Void mainPanel_MouseUp(System::Object^ sender, System::Windows::Forms::MouseEventArgs^ e) {
		// hide labelCoords by placing it "above" the form
		labelCoords->Top = -100;

		// end rotation mode
		inRotationMode = false;
	}

	private: Point2D getWorldCoords(float screenX, float screenY) {
		return { (screenX - panX) / zoomLevel, (screenY - panY) / -zoomLevel };
	}
	private: Point2D getScreenCoords(float worldX, float worldY) {
		return { roundf(worldX * zoomLevel) + panX , roundf(worldY * -zoomLevel) + panY };
	}
	private: System::Void hScrollBarLineWidth_MouseHover(System::Object^ sender, System::EventArgs^ e) {
		feedbackLabel->Text = "Zero width is hairline, other widths are based on overall shape size.";
	}
	private: System::Void hScrollBarLineWidth_ValueChanged(System::Object^ sender, System::EventArgs^ e) {
		mainPanel->Refresh();

	}

	private: float getScaleSizeX() {
		Point2D topCorner = getWorldCoords(10, 10);
		Point2D botCorner = getWorldCoords(90, 20);
		int decimalPlaces = -5;
		float sizeX = roundf(botCorner.x - topCorner.x) * pow(10., decimalPlaces);
		while (sizeX <= 0.) {
			decimalPlaces++;
			sizeX = roundf((botCorner.x - topCorner.x) * pow(10., decimalPlaces));
		}
		sizeX /= pow(10., decimalPlaces);
		return sizeX;

	}
	private: void drawScale(Graphics^ g) {
		if (theGear != nullptr) {
			// convert from screen size and location I want it to appear to
			// corresponding world coords
			Point2D topCorner = getWorldCoords(10, 10);
			Point2D botCorner = getWorldCoords(90, 20);
			float sizeY = (topCorner.y - botCorner.y);
			float sizeX = getScaleSizeX();

			// draw the scale box
			Brush^ fillBrush = gcnew SolidBrush(labelColor->BackColor);
			g->FillRectangle(fillBrush, topCorner.x, botCorner.y, sizeX, sizeY);

			// draw the number
			float locX = topCorner.x + sizeX, locY = botCorner.y;
			g->TranslateTransform(locX, locY);
			g->ScaleTransform(1, -1);
			sizeY = max(1e-8, sizeY);  // sizeY cannot be zero

			System::Drawing::Font^ scaleFont = gcnew System::Drawing::Font(L"Microsoft Sans Serif",
				sizeY, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0));
			g->DrawString(sizeX.ToString(), scaleFont, fillBrush, 0., 0.);
			g->ScaleTransform(1, 1);
			g->TranslateTransform(-locX, -locY);
		}
	}

	private: void drawPolarGrid(Graphics^ g) {
		Pen^ gridPen = gcnew Pen(ColorNG::colorFromHSV(240, 0.2, 1.0), 0.);

		// change center to whatever pin of link
		Point2D transPoint;
		if (theGear == nullptr)
			transPoint = getWorldCoords(mainPanel->Width / 2, mainPanel->Height / 2); // center of screen
		else
			transPoint = theGear->getLocation();

		g->TranslateTransform(transPoint.x, transPoint.y);

		// draw circles
		int numbCircles = 30.; // change as needed
		float circleSpacing = getScaleSizeX() * 0.5;
		float currDiam;

		for (int i = 1; i <= numbCircles; i++) {
			currDiam = circleSpacing * i * 2;
			g->DrawEllipse(gridPen, -currDiam / 2., -currDiam / 2., currDiam, currDiam);
		}

		// draw radial lines
		int groupCount = 8; // 4 lines per group
		for (int i = 0; i < groupCount; i++) {
			g->DrawLine(gridPen, 0., 0., numbCircles * circleSpacing, 0.);
			g->RotateTransform(360. / groupCount / 2.);
			g->DrawLine(gridPen, 2 * circleSpacing, 0., numbCircles * circleSpacing, 0.);
			g->RotateTransform(-360. / groupCount / 4.);
			g->DrawLine(gridPen, 4 * circleSpacing, 0., numbCircles * circleSpacing, 0.);
			g->RotateTransform(360. / groupCount / 2.);
			g->DrawLine(gridPen, 4 * circleSpacing, 0., numbCircles * circleSpacing, 0.);
			g->RotateTransform(360. / groupCount / 4.);
		}

		g->TranslateTransform(-transPoint.x, -transPoint.y);


	}

	private: void drawOrthoGrid(Graphics^ g) {
		Pen^ gridPen = gcnew Pen(ColorNG::colorFromHSV(240, 0.2, 1.0), 0.);
		float spacing = getScaleSizeX() / 2.;
		Point2D topLeftCorner = getWorldCoords(0, 0);
		Point2D botRightCorner = getWorldCoords(mainPanel->Width, mainPanel->Height);
		float minX = topLeftCorner.x, maxX = botRightCorner.x;
		float maxY = topLeftCorner.y, minY = botRightCorner.y;
		float xLimit = max(fabs(minX), fabs(maxX));
		float yLimit = max(fabs(minY), fabs(maxY));
		float currGridX = -spacing;
		float currGridY = -spacing;
		while (currGridX <= xLimit || currGridY <= yLimit) {
			currGridX += spacing;
			currGridY += spacing;
			g->DrawLine(gridPen, currGridX, minY, currGridX, maxY);
			g->DrawLine(gridPen, minX, currGridY, maxX, currGridY);
			g->DrawLine(gridPen, -currGridX, minY, -currGridX, maxY);
			g->DrawLine(gridPen, minX, -currGridY, maxX, -currGridY);
		}
	}

	private: void drawOrthoGrid2(Graphics^ g) {
		Pen^ gridPen = gcnew Pen(ColorNG::colorFromHSV(240, 0.2, 1.0), 0.);
		float spacing, currGridX, currGridY;
		float minX, maxX, minY, maxY;
		if (theGear == nullptr) {
			// draw grid based on what is displayed
			Point2D topLeftCorner = getWorldCoords(0, 0);
			Point2D botRightCorner = getWorldCoords(mainPanel->Width, mainPanel->Height);
			minX = topLeftCorner.x; maxX = botRightCorner.x;
			maxY = topLeftCorner.y; minY = botRightCorner.y;
			spacing = 20.;
			currGridX = currGridY = -spacing;
		}
		else {
			// draw grid based on shape
			spacing = pow(10., (int)log10(gearSize) - 1);
			if (gearSize / spacing > 50)
				spacing *= 2.f;

			Point2D lowerBound = theGear->lowerBoundingBox();
			Point2D upperBound = theGear->upperBoundingBox();

			// draw grid about twice as large as shape
			minX = lowerBound.x - gearSize; minY = lowerBound.y - gearSize;
			maxX = upperBound.x + gearSize; maxY = upperBound.y + gearSize;

			currGridX = round((minX) / spacing) * spacing - spacing;
			currGridY = round((minY) / spacing) * spacing - spacing;
			int i = 1;
		}

		while (currGridX <= maxX || currGridY <= maxY) {
			currGridX += spacing;
			currGridY += spacing;
			if (currGridX <= maxX)
				g->DrawLine(gridPen, currGridX, minY, currGridX, maxY);
			if (currGridY <= maxY)
				g->DrawLine(gridPen, minX, currGridY, maxX, currGridY);
		}
	}
	private: System::Void checkBoxShowGrid_CheckedChanged(System::Object^ sender, System::EventArgs^ e) {
		// Only enable grid type radio buttons if Show Grid is checked 
		radioButtonPolar->Enabled = checkBoxShowGrid->Checked;
		radioButtonOrtho->Enabled = checkBoxShowGrid->Checked;

		mainPanel->Refresh();
	}
	private: System::Void checkBox_JustRefresh(System::Object^ sender, System::EventArgs^ e) {
		mainPanel->Refresh();
	}
	private: System::Void checkBoxFillGear_CheckedChanged(System::Object^ sender, System::EventArgs^ e) {
		checkBoxTransparent->Enabled = checkBoxFillGear->Checked;
		mainPanel->Refresh();
	}

	private: System::Void checkBoxShowLabels_CheckedChanged(System::Object^ sender, System::EventArgs^ e) {
		// Only enable tooth labels and show circles checkboxes if Labels is checked 
		checkBoxShowToothLabels->Enabled = checkBoxShowLabels->Checked;
		checkBoxShowCircles->Enabled = checkBoxShowLabels->Checked;

		mainPanel->Refresh();
	}

	private: System::Void buttonInsert_Click(System::Object^ sender, System::EventArgs^ e) {
		//if (selectedPntIndex != -1) {
		//	if (theGear->addPoint(selectedPntIndex, 0.7))
		//		mainPanel->Refresh();
		//}
	}
	private: System::Void buttonDelete_Click(System::Object^ sender, System::EventArgs^ e) {
		//if (selectedPntIndex != -1) {
		//	if (theGear->removePoint(selectedPntIndex)) {
		//		selectedPntIndex = -1;
		//		highlightedPntIndex = -1;
		//		resetShapeProperties();
		//		mainPanel->Refresh();
		//	}
		//}
	}
	private: int getIntegerFromBox(TextBox^ currBox) {
		String^ boxName = currBox->Name;
		try {
			return Convert::ToInt32(currBox->Text); // could generate exception
		}
		catch (Exception^ e) {
			MessageBox::Show(e->Message + "\n\nUnable to get valid integer from " + boxName);
			currBox->Focus();
			return -MININT;
		}
	}
	private: float getFloatFromBox(TextBox^ currBox) {
		String^ boxName = currBox->Name;
		try {
			return Convert::ToSingle(currBox->Text); // could generate exception
		}
		catch (Exception^ e) {
			MessageBox::Show(e->Message + "\n\nUnable to get valid number from " + boxName);
			currBox->Focus();
			return -INFINITY;
		}
	}
	private: void updatePropertiesDisplay() {
		if (theGear != nullptr) {
			textBoxGearID->Text = gcnew String(theGear->getID().c_str());
			textBoxNumbTeeth->Text = theGear->getNumbTeeth().ToString();
			textBoxPitch->Text = StringPlus::sigFigs(theGear->getPitch(), 3);
			textBoxStartAngle->Text = StringPlus::sigFigs(theGear->getStartAngle(), 3);
			labelForArea->Text = StringPlus::sigFigs(theGear->getArea(), 4);
			labelForPitchDiam->Text = StringPlus::sigFigs(theGear->getPitchDiam(), 4);
			labelColor->BackColor = *theGear->getColor();

			resetLocationBox();
			resetAngleBoxes();


		}
	}

	private: void makeCoordsYellow() {
		//labelCoords->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(255)),
		//	static_cast<System::Int32>(static_cast<System::Byte>(128)));
		labelCoords->BackColor = Color::FromArgb(255, 255, 128);
	}
	private: void makeCoordsOrange() {
		// if I use 4 numbers for color, the first number becomes "alpha" (the transparency)
		// use 0 if you want background to show through, 255 if you don't want any transparancy
		labelCoords->BackColor = Color::FromArgb(105, 255, 128, 0);
	}

	private: void initializeHoverHelp() {
		hoverResponses = gcnew Hashtable;
		hoverResponses->Add(L"textBoxGearID", L"GearID: Unique identifier or part number of the gear");
		hoverResponses->Add(L"textBoxNumbTeeth", L"NumbTeeth: Number of teeth evenly distributed around gear");
		hoverResponses->Add(L"textBoxPitch", L"Pitch: Number of teeth per size of diameter. Only gears with equal pitch can mesh together");
		hoverResponses->Add(L"textBoxLocation", L"Location: Coordinates of gear in 2D space (x,y)");
		hoverResponses->Add(L"textBoxStartAngle", L"StartAngle: Initial rotation of gear (degrees). Zero means one tooth is aligned with x-axis. Mouse drag to change");
		hoverResponses->Add(L"textBoxCurrAngle", L"CurrAngle: Current rotation of gear (degrees). Zero means one tooth is aligned with x-axis");
		hoverResponses->Add(L"labelForPitchDiam", L"Pitch Diameter: Diameter of gear at pitch circle (where gears interact)");
		hoverResponses->Add(L"labelForArea", L"Area: Area of gear shape, including teeth geometry");
		hoverResponses->Add(L"buttonLoad", L"Load: Load a gear file from permanent storage (will over-ride currently loaded gear)");
		hoverResponses->Add(L"buttonSave", L"Save: Save the current gear to a file");
		hoverResponses->Add(L"buttonResetView", L"Reset View: Changes pan and zoom so that gear is centered and scaled to fit on display");
	}
	private: System::Void helpFeedback_MouseHover(System::Object^ sender, System::EventArgs^ e) {
		int temp = 1;
		auto controlName = ((Control^)sender)->Name;
		auto response = hoverResponses[controlName];
		temp = temp;
		if (response != nullptr)
			feedbackLabel->Text = "What is this? -- " + response + ".";
	}

	};
}
