#pragma once
//#include <Windows.h>                // to open other apps

#include <fstream>
#include <chrono>
#include <thread>
#include <string>
#include <Windows.h>
#include<mmsystem.h>

#pragma comment(lib,"shell32.lib")  // to open other apps

#include "DoubleBufferedPanel.h"
	// using flickerless panel makes the form design view not work.
	// to use flickerless panel or allow the design view, use one of these
	// in InitComponents() function
	//    for design view >>>>    this->mainPanel = (gcnew System::Windows::Forms::Panel());
	//    for flickerless >>>>    this->mainPanel = (gcnew DoubleBufferedPanel());

#include "GearTrain.h"
#include "GearEditor.h"
#include "Driver.h"

namespace gearSimulatorPS07ng {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for GearSimulator
	/// </summary>
	public ref class GearSimulator : public System::Windows::Forms::Form
	{
	public:
		GearSimulator(void)
		{
			//theTrain = 
			InitializeComponent();

			// this DID NOT WORK to engage double buffering because we need mainPanel
			// to be double buffered, not the form
			//this->SetStyle(ControlStyles::DoubleBuffer |
			//	ControlStyles::UserPaint |
			//	ControlStyles::AllPaintingInWmPaint,
			//	true);
			//this->UpdateStyles();

			// this DOES NOT WORK because the property is protected (not public)
			// hence, we need to inherit if we want access
			//mainPanel->DoubleBuffered = true;

			labelCoords->Top = -100; // take labelCoords off the screen
			pictureBox2->Top = -100;
			initializeHoverHelp();
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~GearSimulator()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Panel^ mainPanel;
	protected:
	private: System::Windows::Forms::Label^ labelCoords;
	private: System::Windows::Forms::Button^ buttonResetView;
	private: System::Windows::Forms::Label^ feedbackLabel;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Button^ buttonSave;
	private: System::Windows::Forms::Button^ buttonLoad;
	private: System::Windows::Forms::Label^ label9;
	private: System::Windows::Forms::TextBox^ textBoxGearTrainID;


	protected: GearTrain* theTrain = nullptr;
			 Gear2D* currGear = nullptr;
			 Gear2D* otherGear = nullptr;
			 int panX = 300, panY = 300, currX, currY;
			 float zoomLevel = 1.f;
			 bool mouseInPanel = false;
			 float gearSize = 1.f;
			 bool inRotationMode = false;
			 bool waitingForOtherGearToMesh = false;
			 bool waitingForOtherGearToAttach = false;
			 bool waitingForOtherGearToBelt = false;
			 Hashtable^ hoverResponses;
			 Driver* theDriver = nullptr;
			

	private: System::Windows::Forms::Label^ labelCurrGearDescription;
	protected:

	protected:

	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Panel^ panel1;
	private: System::Windows::Forms::Button^ buttonAttachCurrGear;
	private: System::Windows::Forms::Button^ buttonMeshCurrGear;
	private: System::Windows::Forms::Button^ buttonDelCurrGear;
	private: System::Windows::Forms::Button^ buttonEditCurrGear;
	private: System::Windows::Forms::Button^ buttonResetAll;
	private: System::Windows::Forms::Button^ buttonDetachCurrGear;
	private: System::Windows::Forms::Button^ buttonUnmeshCurrGear;
	private: System::Windows::Forms::Button^ buttonAddGear;
	private: System::Windows::Forms::Button^ buttonHelp;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Button^ buttonAddDriver;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ labelDriverID;
	private: System::Windows::Forms::Button^ buttonSimulation;
	private: System::Windows::Forms::PictureBox^ pictureBox2;
	private: System::Windows::Forms::Button^ buttonBeltCurrGear;

	private: System::Windows::Forms::Button^ buttonUnbeltCurrGear;






	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(GearSimulator::typeid));
			this->mainPanel = (gcnew System::Windows::Forms::Panel());
			this->pictureBox2 = (gcnew System::Windows::Forms::PictureBox());
			this->labelCoords = (gcnew System::Windows::Forms::Label());
			this->buttonResetView = (gcnew System::Windows::Forms::Button());
			this->feedbackLabel = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->buttonSave = (gcnew System::Windows::Forms::Button());
			this->buttonLoad = (gcnew System::Windows::Forms::Button());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->textBoxGearTrainID = (gcnew System::Windows::Forms::TextBox());
			this->labelCurrGearDescription = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->buttonUnbeltCurrGear = (gcnew System::Windows::Forms::Button());
			this->buttonBeltCurrGear = (gcnew System::Windows::Forms::Button());
			this->buttonDetachCurrGear = (gcnew System::Windows::Forms::Button());
			this->buttonUnmeshCurrGear = (gcnew System::Windows::Forms::Button());
			this->buttonAttachCurrGear = (gcnew System::Windows::Forms::Button());
			this->buttonMeshCurrGear = (gcnew System::Windows::Forms::Button());
			this->buttonDelCurrGear = (gcnew System::Windows::Forms::Button());
			this->buttonEditCurrGear = (gcnew System::Windows::Forms::Button());
			this->buttonResetAll = (gcnew System::Windows::Forms::Button());
			this->buttonAddGear = (gcnew System::Windows::Forms::Button());
			this->buttonHelp = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->buttonAddDriver = (gcnew System::Windows::Forms::Button());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->labelDriverID = (gcnew System::Windows::Forms::Label());
			this->buttonSimulation = (gcnew System::Windows::Forms::Button());
			this->mainPanel->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->BeginInit();
			this->panel1->SuspendLayout();
			this->SuspendLayout();
			// 
			// mainPanel
			// 
			this->mainPanel->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom)
				| System::Windows::Forms::AnchorStyles::Left)
				| System::Windows::Forms::AnchorStyles::Right));
			this->mainPanel->BackColor = System::Drawing::SystemColors::Window;
			this->mainPanel->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->mainPanel->Controls->Add(this->pictureBox2);
			this->mainPanel->Controls->Add(this->labelCoords);
			this->mainPanel->Location = System::Drawing::Point(171, 62);
			this->mainPanel->Margin = System::Windows::Forms::Padding(4);
			this->mainPanel->Name = L"mainPanel";
			this->mainPanel->Size = System::Drawing::Size(867, 589);
			this->mainPanel->TabIndex = 2;
			this->mainPanel->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &GearSimulator::mainPanel_Paint);
			this->mainPanel->MouseDown += gcnew System::Windows::Forms::MouseEventHandler(this, &GearSimulator::mainPanel_MouseDown);
			this->mainPanel->MouseEnter += gcnew System::EventHandler(this, &GearSimulator::mainPanel_MouseEnter);
			this->mainPanel->MouseLeave += gcnew System::EventHandler(this, &GearSimulator::mainPanel_MouseLeave);
			this->mainPanel->MouseMove += gcnew System::Windows::Forms::MouseEventHandler(this, &GearSimulator::mainPanel_MouseMove);
			this->mainPanel->MouseUp += gcnew System::Windows::Forms::MouseEventHandler(this, &GearSimulator::mainPanel_MouseUp);
			// 
			// pictureBox2
			// 
			this->pictureBox2->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox2.Image")));
			this->pictureBox2->Location = System::Drawing::Point(736, 4);
			this->pictureBox2->Margin = System::Windows::Forms::Padding(4);
			this->pictureBox2->Name = L"pictureBox2";
			this->pictureBox2->Size = System::Drawing::Size(123, 106);
			this->pictureBox2->TabIndex = 1;
			this->pictureBox2->TabStop = false;
			// 
			// labelCoords
			// 
			this->labelCoords->AutoSize = true;
			this->labelCoords->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->labelCoords->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->labelCoords->Location = System::Drawing::Point(153, 31);
			this->labelCoords->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->labelCoords->Name = L"labelCoords";
			this->labelCoords->Size = System::Drawing::Size(107, 18);
			this->labelCoords->TabIndex = 0;
			this->labelCoords->Text = L"Used for Coords";
			// 
			// buttonResetView
			// 
			this->buttonResetView->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->buttonResetView->Location = System::Drawing::Point(979, 7);
			this->buttonResetView->Margin = System::Windows::Forms::Padding(4);
			this->buttonResetView->Name = L"buttonResetView";
			this->buttonResetView->RightToLeft = System::Windows::Forms::RightToLeft::Yes;
			this->buttonResetView->Size = System::Drawing::Size(60, 47);
			this->buttonResetView->TabIndex = 8;
			this->buttonResetView->Text = L"Reset View";
			this->buttonResetView->UseVisualStyleBackColor = true;
			this->buttonResetView->Click += gcnew System::EventHandler(this, &GearSimulator::buttonResetView_Click);
			// 
			// feedbackLabel
			// 
			this->feedbackLabel->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Left));
			this->feedbackLabel->AutoSize = true;
			this->feedbackLabel->Location = System::Drawing::Point(176, 660);
			this->feedbackLabel->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->feedbackLabel->Name = L"feedbackLabel";
			this->feedbackLabel->Size = System::Drawing::Size(25, 16);
			this->feedbackLabel->TabIndex = 9;
			this->feedbackLabel->Text = L"- - -";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Elephant", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->ForeColor = System::Drawing::Color::Red;
			this->label1->Location = System::Drawing::Point(16, 11);
			this->label1->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(169, 35);
			this->label1->TabIndex = 10;
			this->label1->Text = L"Gear-it-Up!";
			// 
			// buttonSave
			// 
			this->buttonSave->Location = System::Drawing::Point(84, 62);
			this->buttonSave->Margin = System::Windows::Forms::Padding(4);
			this->buttonSave->Name = L"buttonSave";
			this->buttonSave->Size = System::Drawing::Size(79, 41);
			this->buttonSave->TabIndex = 12;
			this->buttonSave->Text = L"Save";
			this->buttonSave->UseVisualStyleBackColor = true;
			this->buttonSave->Click += gcnew System::EventHandler(this, &GearSimulator::buttonSave_Click);
			this->buttonSave->MouseHover += gcnew System::EventHandler(this, &GearSimulator::helpFeedback_MouseHover);
			// 
			// buttonLoad
			// 
			this->buttonLoad->Location = System::Drawing::Point(4, 62);
			this->buttonLoad->Margin = System::Windows::Forms::Padding(4);
			this->buttonLoad->Name = L"buttonLoad";
			this->buttonLoad->Size = System::Drawing::Size(79, 41);
			this->buttonLoad->TabIndex = 11;
			this->buttonLoad->Text = L"Load";
			this->buttonLoad->UseVisualStyleBackColor = true;
			this->buttonLoad->Click += gcnew System::EventHandler(this, &GearSimulator::buttonLoad_Click);
			this->buttonLoad->MouseHover += gcnew System::EventHandler(this, &GearSimulator::helpFeedback_MouseHover);
			// 
			// label9
			// 
			this->label9->Location = System::Drawing::Point(4, 107);
			this->label9->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(61, 32);
			this->label9->TabIndex = 14;
			this->label9->Text = L"Gear Train ID";
			this->label9->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
			// 
			// textBoxGearTrainID
			// 
			this->textBoxGearTrainID->Location = System::Drawing::Point(71, 110);
			this->textBoxGearTrainID->Margin = System::Windows::Forms::Padding(4);
			this->textBoxGearTrainID->Name = L"textBoxGearTrainID";
			this->textBoxGearTrainID->Size = System::Drawing::Size(91, 22);
			this->textBoxGearTrainID->TabIndex = 13;
			this->textBoxGearTrainID->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &GearSimulator::textBoxGearTrainID_KeyDown);
			this->textBoxGearTrainID->MouseHover += gcnew System::EventHandler(this, &GearSimulator::helpFeedback_MouseHover);
			// 
			// labelCurrGearDescription
			// 
			this->labelCurrGearDescription->Font = (gcnew System::Drawing::Font(L"Courier New", 6.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->labelCurrGearDescription->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"labelCurrGearDescription.Image")));
			this->labelCurrGearDescription->Location = System::Drawing::Point(1, 32);
			this->labelCurrGearDescription->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->labelCurrGearDescription->Name = L"labelCurrGearDescription";
			this->labelCurrGearDescription->Size = System::Drawing::Size(158, 87);
			this->labelCurrGearDescription->TabIndex = 14;
			this->labelCurrGearDescription->Text = L"- - -";
			this->labelCurrGearDescription->MouseHover += gcnew System::EventHandler(this, &GearSimulator::helpFeedback_MouseHover);
			// 
			// label3
			// 
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"label3.Image")));
			this->label3->Location = System::Drawing::Point(23, 0);
			this->label3->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(113, 32);
			this->label3->TabIndex = 14;
			this->label3->Text = L"Current Gear";
			this->label3->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			// 
			// panel1
			// 
			this->panel1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"panel1.BackgroundImage")));
			this->panel1->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->panel1->Controls->Add(this->buttonUnbeltCurrGear);
			this->panel1->Controls->Add(this->buttonBeltCurrGear);
			this->panel1->Controls->Add(this->buttonDetachCurrGear);
			this->panel1->Controls->Add(this->buttonUnmeshCurrGear);
			this->panel1->Controls->Add(this->buttonAttachCurrGear);
			this->panel1->Controls->Add(this->buttonMeshCurrGear);
			this->panel1->Controls->Add(this->buttonDelCurrGear);
			this->panel1->Controls->Add(this->buttonEditCurrGear);
			this->panel1->Controls->Add(this->label3);
			this->panel1->Controls->Add(this->labelCurrGearDescription);
			this->panel1->Location = System::Drawing::Point(5, 314);
			this->panel1->Margin = System::Windows::Forms::Padding(4);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(163, 255);
			this->panel1->TabIndex = 15;
			// 
			// buttonUnbeltCurrGear
			// 
			this->buttonUnbeltCurrGear->Location = System::Drawing::Point(78, 122);
			this->buttonUnbeltCurrGear->Name = L"buttonUnbeltCurrGear";
			this->buttonUnbeltCurrGear->Size = System::Drawing::Size(75, 23);
			this->buttonUnbeltCurrGear->TabIndex = 17;
			this->buttonUnbeltCurrGear->Text = L"Unbelt";
			this->buttonUnbeltCurrGear->UseVisualStyleBackColor = true;
			this->buttonUnbeltCurrGear->Click += gcnew System::EventHandler(this, &GearSimulator::buttonUnbeltCurrGear_Click);
			// 
			// buttonBeltCurrGear
			// 
			this->buttonBeltCurrGear->Location = System::Drawing::Point(6, 122);
			this->buttonBeltCurrGear->Name = L"buttonBeltCurrGear";
			this->buttonBeltCurrGear->Size = System::Drawing::Size(64, 23);
			this->buttonBeltCurrGear->TabIndex = 16;
			this->buttonBeltCurrGear->Text = L"Belt";
			this->buttonBeltCurrGear->UseVisualStyleBackColor = true;
			this->buttonBeltCurrGear->Click += gcnew System::EventHandler(this, &GearSimulator::buttonBeltCurrGear_Click);
			// 
			// buttonDetachCurrGear
			// 
			this->buttonDetachCurrGear->Location = System::Drawing::Point(76, 187);
			this->buttonDetachCurrGear->Margin = System::Windows::Forms::Padding(4);
			this->buttonDetachCurrGear->Name = L"buttonDetachCurrGear";
			this->buttonDetachCurrGear->Size = System::Drawing::Size(77, 27);
			this->buttonDetachCurrGear->TabIndex = 15;
			this->buttonDetachCurrGear->Text = L"Detach";
			this->buttonDetachCurrGear->UseVisualStyleBackColor = true;
			this->buttonDetachCurrGear->Click += gcnew System::EventHandler(this, &GearSimulator::buttonDetachCurrGear_Click);
			this->buttonDetachCurrGear->MouseHover += gcnew System::EventHandler(this, &GearSimulator::helpFeedback_MouseHover);
			// 
			// buttonUnmeshCurrGear
			// 
			this->buttonUnmeshCurrGear->Location = System::Drawing::Point(76, 152);
			this->buttonUnmeshCurrGear->Margin = System::Windows::Forms::Padding(4);
			this->buttonUnmeshCurrGear->Name = L"buttonUnmeshCurrGear";
			this->buttonUnmeshCurrGear->Size = System::Drawing::Size(77, 27);
			this->buttonUnmeshCurrGear->TabIndex = 15;
			this->buttonUnmeshCurrGear->Text = L"Unmesh";
			this->buttonUnmeshCurrGear->UseVisualStyleBackColor = true;
			this->buttonUnmeshCurrGear->Click += gcnew System::EventHandler(this, &GearSimulator::buttonUnmeshCurrGear_Click);
			this->buttonUnmeshCurrGear->MouseHover += gcnew System::EventHandler(this, &GearSimulator::helpFeedback_MouseHover);
			// 
			// buttonAttachCurrGear
			// 
			this->buttonAttachCurrGear->Location = System::Drawing::Point(4, 187);
			this->buttonAttachCurrGear->Margin = System::Windows::Forms::Padding(4);
			this->buttonAttachCurrGear->Name = L"buttonAttachCurrGear";
			this->buttonAttachCurrGear->Size = System::Drawing::Size(64, 27);
			this->buttonAttachCurrGear->TabIndex = 15;
			this->buttonAttachCurrGear->Text = L"Attach";
			this->buttonAttachCurrGear->UseVisualStyleBackColor = true;
			this->buttonAttachCurrGear->Click += gcnew System::EventHandler(this, &GearSimulator::buttonAttachCurrGear_Click);
			this->buttonAttachCurrGear->MouseHover += gcnew System::EventHandler(this, &GearSimulator::helpFeedback_MouseHover);
			// 
			// buttonMeshCurrGear
			// 
			this->buttonMeshCurrGear->Location = System::Drawing::Point(7, 152);
			this->buttonMeshCurrGear->Margin = System::Windows::Forms::Padding(4);
			this->buttonMeshCurrGear->Name = L"buttonMeshCurrGear";
			this->buttonMeshCurrGear->Size = System::Drawing::Size(64, 27);
			this->buttonMeshCurrGear->TabIndex = 15;
			this->buttonMeshCurrGear->Text = L"Mesh";
			this->buttonMeshCurrGear->UseVisualStyleBackColor = true;
			this->buttonMeshCurrGear->Click += gcnew System::EventHandler(this, &GearSimulator::buttonMeshCurrGear_Click);
			this->buttonMeshCurrGear->MouseHover += gcnew System::EventHandler(this, &GearSimulator::helpFeedback_MouseHover);
			// 
			// buttonDelCurrGear
			// 
			this->buttonDelCurrGear->Location = System::Drawing::Point(76, 222);
			this->buttonDelCurrGear->Margin = System::Windows::Forms::Padding(4);
			this->buttonDelCurrGear->Name = L"buttonDelCurrGear";
			this->buttonDelCurrGear->Size = System::Drawing::Size(77, 27);
			this->buttonDelCurrGear->TabIndex = 15;
			this->buttonDelCurrGear->Text = L"Del";
			this->buttonDelCurrGear->UseVisualStyleBackColor = true;
			this->buttonDelCurrGear->Click += gcnew System::EventHandler(this, &GearSimulator::buttonDelCurrGear_Click);
			this->buttonDelCurrGear->MouseHover += gcnew System::EventHandler(this, &GearSimulator::helpFeedback_MouseHover);
			// 
			// buttonEditCurrGear
			// 
			this->buttonEditCurrGear->Location = System::Drawing::Point(4, 222);
			this->buttonEditCurrGear->Margin = System::Windows::Forms::Padding(4);
			this->buttonEditCurrGear->Name = L"buttonEditCurrGear";
			this->buttonEditCurrGear->Size = System::Drawing::Size(64, 27);
			this->buttonEditCurrGear->TabIndex = 15;
			this->buttonEditCurrGear->Text = L"Edit";
			this->buttonEditCurrGear->UseVisualStyleBackColor = true;
			this->buttonEditCurrGear->Click += gcnew System::EventHandler(this, &GearSimulator::buttonEditCurrGear_Click);
			this->buttonEditCurrGear->MouseHover += gcnew System::EventHandler(this, &GearSimulator::helpFeedback_MouseHover);
			// 
			// buttonResetAll
			// 
			this->buttonResetAll->Location = System::Drawing::Point(8, 193);
			this->buttonResetAll->Margin = System::Windows::Forms::Padding(4);
			this->buttonResetAll->Name = L"buttonResetAll";
			this->buttonResetAll->Size = System::Drawing::Size(160, 31);
			this->buttonResetAll->TabIndex = 11;
			this->buttonResetAll->Text = L"Reset All Gears";
			this->buttonResetAll->UseVisualStyleBackColor = true;
			this->buttonResetAll->Click += gcnew System::EventHandler(this, &GearSimulator::buttonResetAll_Click);
			this->buttonResetAll->MouseHover += gcnew System::EventHandler(this, &GearSimulator::helpFeedback_MouseHover);
			// 
			// buttonAddGear
			// 
			this->buttonAddGear->Location = System::Drawing::Point(5, 155);
			this->buttonAddGear->Margin = System::Windows::Forms::Padding(4);
			this->buttonAddGear->Name = L"buttonAddGear";
			this->buttonAddGear->Size = System::Drawing::Size(160, 31);
			this->buttonAddGear->TabIndex = 11;
			this->buttonAddGear->Text = L"Add Gear";
			this->buttonAddGear->UseVisualStyleBackColor = true;
			this->buttonAddGear->Click += gcnew System::EventHandler(this, &GearSimulator::buttonAddGear_Click);
			this->buttonAddGear->MouseHover += gcnew System::EventHandler(this, &GearSimulator::helpFeedback_MouseHover);
			// 
			// buttonHelp
			// 
			this->buttonHelp->Location = System::Drawing::Point(909, 7);
			this->buttonHelp->Margin = System::Windows::Forms::Padding(4);
			this->buttonHelp->Name = L"buttonHelp";
			this->buttonHelp->Size = System::Drawing::Size(61, 47);
			this->buttonHelp->TabIndex = 16;
			this->buttonHelp->Text = L"Help";
			this->buttonHelp->UseVisualStyleBackColor = true;
			this->buttonHelp->Click += gcnew System::EventHandler(this, &GearSimulator::buttonHelp_Click);
			// 
			// label2
			// 
			this->label2->Location = System::Drawing::Point(9, 612);
			this->label2->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(153, 76);
			this->label2->TabIndex = 14;
			this->label2->Text = L"Drag to rotate\nCtrl+Drag to move\nShft+Left for coords";
			this->label2->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			// 
			// buttonAddDriver
			// 
			this->buttonAddDriver->Location = System::Drawing::Point(8, 231);
			this->buttonAddDriver->Margin = System::Windows::Forms::Padding(4);
			this->buttonAddDriver->Name = L"buttonAddDriver";
			this->buttonAddDriver->Size = System::Drawing::Size(160, 31);
			this->buttonAddDriver->TabIndex = 11;
			this->buttonAddDriver->Text = L"Add Driver";
			this->buttonAddDriver->UseVisualStyleBackColor = true;
			this->buttonAddDriver->Click += gcnew System::EventHandler(this, &GearSimulator::buttonAddDriver_Click);
			this->buttonAddDriver->MouseHover += gcnew System::EventHandler(this, &GearSimulator::helpFeedback_MouseHover);
			// 
			// label4
			// 
			this->label4->Location = System::Drawing::Point(1, 267);
			this->label4->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(61, 32);
			this->label4->TabIndex = 14;
			this->label4->Text = L"Driver ID";
			this->label4->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
			// 
			// labelDriverID
			// 
			this->labelDriverID->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->labelDriverID->ImageAlign = System::Drawing::ContentAlignment::MiddleLeft;
			this->labelDriverID->Location = System::Drawing::Point(71, 267);
			this->labelDriverID->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->labelDriverID->Name = L"labelDriverID";
			this->labelDriverID->Size = System::Drawing::Size(94, 32);
			this->labelDriverID->TabIndex = 14;
			this->labelDriverID->Text = L"- - -";
			this->labelDriverID->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			// 
			// buttonSimulation
			// 
			this->buttonSimulation->BackColor = System::Drawing::Color::Lime;
			this->buttonSimulation->Location = System::Drawing::Point(7, 577);
			this->buttonSimulation->Margin = System::Windows::Forms::Padding(4);
			this->buttonSimulation->Name = L"buttonSimulation";
			this->buttonSimulation->Size = System::Drawing::Size(160, 31);
			this->buttonSimulation->TabIndex = 11;
			this->buttonSimulation->Text = L"Start Simulation";
			this->buttonSimulation->UseVisualStyleBackColor = false;
			this->buttonSimulation->Click += gcnew System::EventHandler(this, &GearSimulator::buttonSimulation_Click);
			this->buttonSimulation->MouseHover += gcnew System::EventHandler(this, &GearSimulator::helpFeedback_MouseHover);
			// 
			// GearSimulator
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->ClientSize = System::Drawing::Size(1055, 687);
			this->Controls->Add(this->buttonHelp);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->labelDriverID);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->textBoxGearTrainID);
			this->Controls->Add(this->buttonSave);
			this->Controls->Add(this->buttonAddGear);
			this->Controls->Add(this->buttonSimulation);
			this->Controls->Add(this->buttonAddDriver);
			this->Controls->Add(this->buttonResetAll);
			this->Controls->Add(this->buttonLoad);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->feedbackLabel);
			this->Controls->Add(this->buttonResetView);
			this->Controls->Add(this->mainPanel);
			this->Margin = System::Windows::Forms::Padding(4);
			this->Name = L"GearSimulator";
			this->Text = L" ";
			this->MouseWheel += gcnew System::Windows::Forms::MouseEventHandler(this, &GearSimulator::GearSimulator_MouseWheel);
			this->mainPanel->ResumeLayout(false);
			this->mainPanel->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->EndInit();
			this->panel1->ResumeLayout(false);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void mainPanel_Paint(System::Object^ sender, System::Windows::Forms::PaintEventArgs^ e) {
		auto g = e->Graphics;
		g->SmoothingMode = System::Drawing::Drawing2D::SmoothingMode::AntiAlias;

		std::vector<Point2D> beltPoints;

		if (waitingForOtherGearToMesh) {
			int lineWidth = 6;
			g->DrawRectangle(gcnew Pen(Color::LimeGreen, lineWidth), lineWidth / 2, lineWidth / 2,
				mainPanel->Width - lineWidth * 2, mainPanel->Height - lineWidth * 2);
		}

		if (waitingForOtherGearToAttach) {
			int lineWidth = 6;
			g->DrawRectangle(gcnew Pen(Color::LimeGreen, lineWidth), lineWidth / 2, lineWidth / 2,
				mainPanel->Width - lineWidth * 2, mainPanel->Height - lineWidth * 2);
		}

		if (waitingForOtherGearToBelt) {
			int lineWidth = 6;
			g->DrawRectangle(gcnew Pen(Color::LimeGreen, lineWidth), lineWidth / 2, lineWidth / 2,
				mainPanel->Width - lineWidth * 2, mainPanel->Height - lineWidth * 2);
			/*if (currGear != nullptr && otherGear != nullptr) {
				Point2D currLoc = currGear->getLocation();
				Point2D otherLoc = otherGear->getLocation();
				beltPoints.push_back(currLoc);
				beltPoints.push_back(otherLoc);
			}*/
		
		}

		g->TranslateTransform(panX, panY);
		g->ScaleTransform(zoomLevel, -zoomLevel);
		if (theTrain != nullptr) {
			theTrain->paint(g);

			if (currGear != nullptr) {
				// highlight current gear (using circles)
				currGear->paint(g, nullptr, false, false, true);
			}

			if (otherGear != nullptr) {
				// highlight other gear (painting red)
				otherGear->paint(g, Color::Red, true, false, false, true, true);
			}
		}
	}

	private: System::Void mainPanel_MouseDown(System::Object^ sender, System::Windows::Forms::MouseEventArgs^ e) {
		// this if is part of panning (sets the initial mousewheel click position)
		if (e->Button == System::Windows::Forms::MouseButtons::Middle
			|| e->Button == System::Windows::Forms::MouseButtons::Left) {
			currX = e->X;
			currY = e->Y;
		}
		if (e->Button == System::Windows::Forms::MouseButtons::Left) {
			if (Control::ModifierKeys == Keys::Shift) {
				// show coords on popup yellow window
				makeCoordsYellow();
				Point2D clickedPnt;
				if (theTrain != nullptr) {
					clickedPnt = getWorldCoords(e->X, e->Y);
					//if (theGear->isContained(clickedPnt))
					//	makeCoordsOrange();
				}
				else
					clickedPnt = { e->X * 1.f, e->Y * 1.f }; // need to convert to float

				labelCoords->Text = StringPlus::sigFigs(clickedPnt.x, 4) + ", " + StringPlus::sigFigs(clickedPnt.y, 4);
				labelCoords->Top = e->Y + 10 /*+ mainPanel->Top*/;     // no need for mainPanel adjustment now that labelCoords is inside mainPanel
				labelCoords->Left = e->X + 15 /*+ mainPanel->Left*/;
			}
			else if (theTrain != nullptr) {
				// if click is on a gear, 
				Point2D clickPnt = getWorldCoords(e->X, e->Y);
				Gear2D* selectedGear = theTrain->getGear(clickPnt);

				if (selectedGear == nullptr) {
					inRotationMode = false;
					if (waitingForOtherGearToMesh || waitingForOtherGearToAttach) {
						feedbackLabel->Text = "Select other gear to ";
						feedbackLabel->Text = waitingForOtherGearToMesh ? "mesh into." : "attach to";
						otherGear = nullptr;  // clear selection
					}
					else {
						currGear = nullptr;
						updatePropertiesDisplay();
					}
				}
				else {
					if (waitingForOtherGearToMesh) {
						// set up other gear
						//theTrain->setOtherGear(*selectedGear);
						if (selectedGear == currGear)
							feedbackLabel->Text = "That is the current gear. Select other gear to mesh into.";
						else if (theTrain->areMeshable(*currGear, *selectedGear)) {
							otherGear = selectedGear;
							feedbackLabel->Text = gcnew String(otherGear->getID().c_str());
							feedbackLabel->Text += " selected. Click on Mesh Button again to complete meshing";
						}
						else
							feedbackLabel->Text = "Gear selected is not compatible. Select other gear to mesh into.";
					}
					else if (waitingForOtherGearToAttach) {
						if (selectedGear == currGear)
							feedbackLabel->Text = "That is the current gear. Select other gear to attach to.";
						else {
							otherGear = selectedGear;
							feedbackLabel->Text = gcnew String(otherGear->getID().c_str());
							feedbackLabel->Text += " selected. Click on Attach Button again to complete attachment";
						}
					}
					else if (waitingForOtherGearToBelt) {
						if (selectedGear == currGear)
							feedbackLabel->Text = "That is the current gear. Select other gear to attach to.";
						else {
							otherGear = selectedGear;
							feedbackLabel->Text = gcnew String(otherGear->getID().c_str());
							feedbackLabel->Text += " selected. Click on Belt Button again to complete attachment";
						}
			
						
					}
					else {// make it the current gear and start rotation process
						currGear = selectedGear;
						updatePropertiesDisplay();
						inRotationMode = true;
					}
				}

				mainPanel->Refresh();
			}
		}

	}
	private: System::Void mainPanel_MouseMove(System::Object^ sender, System::Windows::Forms::MouseEventArgs^ e) {
		// this function allows panning by pressing down on mousewheel and dragging
		// essentially, we adjust panning by however much the mouse is moved
		if (e->Button == System::Windows::Forms::MouseButtons::Middle) {
			// pan the screen
			panX += (e->X - currX);
			panY += (e->Y - currY);
			mainPanel->Refresh();  // this will "repaint" the main panel
			currX = e->X; currY = e->Y; // need to constantly update to allow drag
		}
		else if (e->Button == System::Windows::Forms::MouseButtons::Left && inRotationMode) {
			Point2D prevWorldPnt = getWorldCoords(currX, currY);
			Point2D currWorldPnt = getWorldCoords(e->X, e->Y);

			//Gear2D* currGear = theTrain->getCurrGear();

			if (Control::ModifierKeys == Keys::Control) {
				// change location of current gear
				Point2D deltaLoc = { currWorldPnt.x - prevWorldPnt.x , currWorldPnt.y - prevWorldPnt.y };
				currGear->move(deltaLoc);
				// theTrain->recalcTrain(); // but it is protected (should change to public?)
			}
			else {
				// change currAngle of current gear
				float prevAngle = Line2D::getAngle(currGear->getLocation(), prevWorldPnt);
				float currAngle = Line2D::getAngle(currGear->getLocation(), currWorldPnt);
				float deltaAngle = /*roundf*/(currAngle - prevAngle);

				currGear->rotate(deltaAngle);
			}
			updatePropertiesDisplay();
			mainPanel->Refresh();

			currX = e->X; currY = e->Y; // need to constantly update to allow drag

		}
	}
	private: System::Void mainPanel_MouseEnter(System::Object^ sender, System::EventArgs^ e) {
		mouseInPanel = true;
	}
	private: System::Void mainPanel_MouseLeave(System::Object^ sender, System::EventArgs^ e) {
		mouseInPanel = false;
	}
	private: void GearSimulator_MouseWheel(Object^ sender, System::Windows::Forms::MouseEventArgs^ e)
	{
		// panel does not take a mousewheel event, so we must handle it at the the level of the form
		// but only if the mouse pointer is inside the panel
		if (mouseInPanel) {

			float oldZoom = zoomLevel; // will need to remember this when resetting panX and panY

			float zoomStep = 1.2f;  // change as needed for more effect per wheel roll
			//e->Delta * SystemInformation::MouseWheelScrollLines / 120
			if (e->Delta < 0) // down roll so zoom out
				zoomLevel = zoomLevel / zoomStep;
			else   // up roll so zoom in
				zoomLevel = zoomLevel * zoomStep;

			// get actual location of pointer inside the panel (as opposed to the form itself)
			int adjustedX = e->X - mainPanel->Location.X - mainPanel->Margin.Left;
			int adjustedY = e->Y - mainPanel->Location.Y - mainPanel->Margin.Top;


			// reset panX and panY such that the coords under the mouse pointer are unchanged
			// i.e., we can zoom in/out on a specific point
			panX = (int)round((adjustedX * (oldZoom - zoomLevel)
				+ panX * zoomLevel) / oldZoom);
			panY = (int)round((adjustedY * (oldZoom - zoomLevel)
				+ panY * zoomLevel) / oldZoom);

			mainPanel->Refresh();

		}
	}
	private: System::Void mainPanel_MouseUp(System::Object^ sender, System::Windows::Forms::MouseEventArgs^ e) {
		// hide labelCoords by placing it "above" the form
		labelCoords->Top = -100;

		// end rotation mode
		inRotationMode = false;
	}

	private: void resetView() {
		if (theTrain != nullptr) {
			Point2D lowerBound = theTrain->lowerBoundingBox();
			Point2D upperBound = theTrain->upperBoundingBox();
			if (lowerBound.x > -INFINITY && upperBound.x > -INFINITY) {
				float gearHeight = upperBound.y - lowerBound.y;
				float gearWidth = upperBound.x - lowerBound.x;

				// don't want height or width to be zero since we'll used them to divide
				gearHeight = max(0.01, gearHeight);  // may need to #include <algorithm> to use min and max
				gearWidth = max(0.01, gearWidth);    // may need to #include <algorithm> to use min and max

				gearSize = max(gearHeight, gearWidth); // for calculating line width

				float heightRatio = mainPanel->Height / gearHeight;
				float widthRatio = mainPanel->Width / gearWidth;

				float borderSpaceRatio = 0.85;  // value of 1.0 will leave no white space around gear
				zoomLevel = min(heightRatio, widthRatio) * borderSpaceRatio;  // may need to #include <algorithm> to use min and max

				panY = mainPanel->Height / 2;
				panX = mainPanel->Width / 2;
				panX += -(upperBound.x + lowerBound.x) / 2. * zoomLevel;
				panY += (upperBound.y + lowerBound.y) / 2. * zoomLevel;
				// note that panY adjustment is not negative because panY is applied before scaling

				mainPanel->Refresh();
			}
		}
	}
	private: void initializeHoverHelp() {

		hoverResponses = gcnew Hashtable;
		hoverResponses->Add(L"textBoxGearTrainID", L"ID: Unique identifier for the gear train");
		hoverResponses->Add(L"buttonMeshCurrGear", L"Mesh: Meshes the current gear into another gear");
		hoverResponses->Add(L"buttonAttachCurrGear", L"Attach: Attach the current gear to another gear");
		hoverResponses->Add(L"buttonUnmeshCurrGear", L"Unmesh: Removes all meshing relationships of current gear");
		hoverResponses->Add(L"buttonDetachCurrGear", L"Detach: Removes all attachment relationships of current gear");
		hoverResponses->Add(L"buttonEditCurrGear", L"Edit: Open the Gear Editor window to edit the current gear");
		hoverResponses->Add(L"buttonDelCurrGear", L"Delete: Remove current gear from gear train (after confirmation)");
		hoverResponses->Add(L"labelCurrGearDescription", L"Description: Parameters of current gear");
		hoverResponses->Add(L"buttonLoad", L"Load: Load a gear train from permanent storage (will over-ride currently loaded gear)");
		hoverResponses->Add(L"buttonSave", L"Save: Save the current gear train to a file");
		hoverResponses->Add(L"buttonResetView", L"Reset View: Changes pan and zoom so that whole train is centered and scaled to fit on display");
		hoverResponses->Add(L"buttonResetAll", L"Reset All: Return simulation to its starting state");
		hoverResponses->Add(L"buttonAddGear", L"Add Gear: Open the GearEditor to create a gear");
	}
	private: System::Void helpFeedback_MouseHover(System::Object^ sender, System::EventArgs^ e) {
		int temp = 1;
		auto controlName = ((Control^)sender)->Name;
		auto response = hoverResponses[controlName];
		temp = temp;
		if (response != nullptr)
			feedbackLabel->Text = "What is this? -- " + response + ".";
	}

	private: Point2D getWorldCoords(float screenX, float screenY) {
		return { (screenX - panX) / zoomLevel, (screenY - panY) / -zoomLevel };
	}
	private: Point2D getScreenCoords(float worldX, float worldY) {
		return { roundf(worldX * zoomLevel) + panX , roundf(worldY * -zoomLevel) + panY };
	}

	private: void makeCoordsYellow() {
		//labelCoords->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(255)),
		//	static_cast<System::Int32>(static_cast<System::Byte>(128)));
		labelCoords->BackColor = Color::FromArgb(255, 255, 128);
	}
	private: void makeCoordsOrange() {
		// if I use 4 numbers for color, the first number becomes "alpha" (the transparency)
		// use 0 if you want background to show through, 255 if you don't want any transparancy
		labelCoords->BackColor = Color::FromArgb(105, 255, 128, 0);
	}

	private: System::Void buttonResetView_Click(System::Object^ sender, System::EventArgs^ e) {
		resetView();
	}

	private: System::Void buttonResetAll_Click(System::Object^ sender, System::EventArgs^ e) {
		if (theTrain != nullptr) {
			theTrain->resetAll();
			updatePropertiesDisplay();
			mainPanel->Refresh();

		}
	}

	private: void updatePropertiesDisplay() {
		if (theTrain != nullptr) {
			textBoxGearTrainID->Text = gcnew String(theTrain->getID().c_str());
			//Gear2D* currGear = theTrain->getCurrGear();
			if (currGear != nullptr)
				labelCurrGearDescription->Text = gcnew String(currGear->getDescription().c_str());
			else
				labelCurrGearDescription->Text = "";
		}
	}

	private: System::Void buttonLoad_Click(System::Object^ sender, System::EventArgs^ e) {
		IO::Stream^ myStream; // needed to capture the results
		OpenFileDialog^ theDialog = gcnew OpenFileDialog;

		theDialog->InitialDirectory = ".";  // current folder
		theDialog->Filter = "Gear files (*.train)|*.train|All files (*.*)|*.*";
		theDialog->FilterIndex = 1;  // will show only linkage files, but user can choose to show all files
		theDialog->Multiselect = false;  // this is the default, but nice to know
		theDialog->RestoreDirectory = true; // will remember last directory/folder used

		// just a test
		//PlaySound(TEXT("screamtest.wav"), NULL, SND_FILENAME);

		// actually open the file dialog and get the name of the file user wants
		if (theDialog->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
			// user did not press cancel button nor closed the dialog
			// create filestream for the file
			if ((myStream = theDialog->OpenFile()) != nullptr)
			{
				feedbackLabel->Text = theDialog->FileName + " is opening";

				myStream->Close();  // don't need it anymore
				std::ifstream inFile;
				inFile.open(StringPlus::convertString(theDialog->FileName)); // needs StringPlus.h

				if (inFile.is_open()) {
					// do whatever you need with inFile (like use it to create a gear train, maybe)

					// if there is a gear already, clear the memory (instead of just abandon it)
					if (theTrain != nullptr)
						delete theTrain;  // follow the pointer and "release" the memory

					theTrain = new GearTrain(inFile); // allocate new memory and let my variable point to it

					inFile.close();

					updatePropertiesDisplay();
					resetView();

					//mainPanel->Refresh();  // not needed since resetView() does it
				}
				else {
					// provide feedback that you were unable to open file ???
					feedbackLabel->Text = " ERROR: Could not open " + theDialog->FileName;
				}
			}
		}
	}
	private: System::Void buttonMeshCurrGear_Click(System::Object^ sender, System::EventArgs^ e) {
		if (theTrain != nullptr) {
			if (currGear != nullptr) {
				if (otherGear == nullptr) {
					if (waitingForOtherGearToMesh) {
						// cancel mesh operation
						waitingForOtherGearToMesh = false;
						changeEnablingAllButtons(!waitingForOtherGearToMesh);
						feedbackLabel->Text = "Cancelled mesh operation";
					}
					else {
						feedbackLabel->Text = "Select other gear to mesh into or Mesh Button without selection to cancel.";
						waitingForOtherGearToMesh = true;
						changeEnablingAllButtons(!waitingForOtherGearToMesh);
						buttonMeshCurrGear->Enabled = true;
					}
				}
				else {
					// do the meshing
					theTrain->meshGears(*currGear, *otherGear);
					otherGear = nullptr;
					waitingForOtherGearToMesh = false;
					changeEnablingAllButtons(!waitingForOtherGearToMesh);
				}
			}
			else
				feedbackLabel->Text = "Must select a gear before trying to mesh";

			mainPanel->Refresh();
		}
		else
			feedbackLabel->Text = "No gears to mesh";
	}
	private: System::Void buttonAttachCurrGear_Click(System::Object^ sender, System::EventArgs^ e) {
		if (theTrain != nullptr) {
			if (currGear != nullptr) {
				if (otherGear == nullptr) {
					if (waitingForOtherGearToAttach) {
						// cancel mesh operation
						waitingForOtherGearToAttach = false;
						changeEnablingAllButtons(!waitingForOtherGearToAttach);
						feedbackLabel->Text = "Cancelled attach operation";
					}
					else {
						feedbackLabel->Text = "Select other gear to mesh into or Attach Button without selection to cancel.";
						waitingForOtherGearToAttach = true;
						changeEnablingAllButtons(!waitingForOtherGearToAttach);
						buttonAttachCurrGear->Enabled = true;
					}
				}
				else {
					// do the attach
					theTrain->attachGears(*currGear, *otherGear);
					otherGear = nullptr;
					waitingForOtherGearToAttach = false;
					changeEnablingAllButtons(!waitingForOtherGearToAttach);
				}
			}
			else
				feedbackLabel->Text = "Must select a gear before trying to attach";

			mainPanel->Refresh();
		}
		else
			feedbackLabel->Text = "No gears to attach";
	}
	private: System::Void buttonSave_Click(System::Object^ sender, System::EventArgs^ e) {
		if (theTrain != nullptr) {
			IO::Stream^ myStream; // needed to capture the results
			SaveFileDialog^ theDialog = gcnew SaveFileDialog;

			theDialog->InitialDirectory = ".";  // current folder
			theDialog->Filter = "Gear files (*.train)|*.train|All files (*.*)|*.*";
			theDialog->FilterIndex = 1;  // will show only linkage files, but user can choose to show all files
			theDialog->RestoreDirectory = true; // will remember last directory/folder used

			// actually open the file dialog and get the name of the file user wants
			if (theDialog->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
				// user did not press cancel button nor closed the dialog
				// create filestream for the file
				if ((myStream = theDialog->OpenFile()) != nullptr)
				{
					feedbackLabel->Text = theDialog->FileName + " is opening";

					myStream->Close();  // don't need it anymore
					std::ofstream outFile;
					outFile.open(StringPlus::convertString(theDialog->FileName)); // needs StringPlus.h

					if (outFile.is_open()) {
						// do whatever you need with outFile (like use it to output a gear, maybe)
						outFile << *theTrain; // follow the pointer then output

						outFile.close();

					}
					else {
						// provide feedback that you were unable to open file ???
						feedbackLabel->Text = " ERROR: Could not save to " + theDialog->FileName;
					}
				}
			}
		}
		else {
			feedbackLabel->Text = " ERROR: There is nothing to save.";
		}

	}
	private: System::Void textBoxGearTrainID_KeyDown(System::Object^ sender, System::Windows::Forms::KeyEventArgs^ e) {
		if (theTrain != nullptr && e->KeyCode == Keys::Enter) {
			e->SuppressKeyPress = true;

			theTrain->setID(StringPlus::convertString(textBoxGearTrainID->Text));
			mainPanel->Refresh();
		}
	}
	private: System::Void buttonDelCurrGear_Click(System::Object^ sender, System::EventArgs^ e) {
		if (theTrain != nullptr && currGear != nullptr) {
			// confirm that user wants to delete
			std::string message = "Are you sure you want to delete gear " + currGear->getID() + " from gear train?";
			auto result = MessageBox::Show(this, gcnew String(message.c_str()), "CONFIRM",
				MessageBoxButtons::YesNo, MessageBoxIcon::Question);
			if (result == System::Windows::Forms::DialogResult::Yes) {
				feedbackLabel->Text = "Gear " + gcnew String(currGear->getID().c_str()) + " has been deleted";
				theTrain->deleteGear(*currGear);
				currGear = nullptr;
				mainPanel->Refresh();
				updatePropertiesDisplay();
			}
		}
	}
	private: System::Void buttonUnmeshCurrGear_Click(System::Object^ sender, System::EventArgs^ e) {
		if (theTrain != nullptr && currGear != nullptr) {
			// confirm that user wants to delete
			std::string message = "Are you sure you want to unmesh gear " + currGear->getID() + " from all other gears?";
			auto result = MessageBox::Show(this, gcnew String(message.c_str()), "CONFIRM",
				MessageBoxButtons::YesNo, MessageBoxIcon::Question);
			if (result == System::Windows::Forms::DialogResult::Yes) {
				feedbackLabel->Text = "Gear " + gcnew String(currGear->getID().c_str()) + " has been unmeshed";
				currGear->unmeshAll();
				//currGear = nullptr;
				//mainPanel->Refresh();
				//updatePropertiesDisplay();
			}

		}
	}
	private: System::Void buttonDetachCurrGear_Click(System::Object^ sender, System::EventArgs^ e) {
		if (theTrain != nullptr && currGear != nullptr) {
			// confirm that user wants to delete
			std::string message = "Are you sure you want to detach gear " + currGear->getID() + " from all other gears?";
			auto result = MessageBox::Show(this, gcnew String(message.c_str()), "CONFIRM",
				MessageBoxButtons::YesNo, MessageBoxIcon::Question);
			if (result == System::Windows::Forms::DialogResult::Yes) {
				feedbackLabel->Text = "Gear " + gcnew String(currGear->getID().c_str()) + " has been detached";
				currGear->unattachAll();
				//currGear = nullptr;
				//mainPanel->Refresh();
				//updatePropertiesDisplay();
			}

		}
	}
	private: System::Void buttonEditCurrGear_Click(System::Object^ sender, System::EventArgs^ e) {

		// open up gear editor and have it edit the current gear
		// 
		// need some changes in GearEditor
			// allow variable theGear to be assigned in constructor
			// instead of deleting gear on load, just readFile instead

		if (currGear != nullptr) {
			GearEditor gearForm(currGear);
			gearForm.ShowDialog();
			theTrain->recalcTrain();
			mainPanel->Refresh();
			updatePropertiesDisplay();
			// what to do about meshedInto and attachedTo  ? ? ?
		}
		else
			feedbackLabel->Text = "Must select a gear to edit its properties";

	}
	private: System::Void buttonAddGear_Click(System::Object^ sender, System::EventArgs^ e) {
		if (theTrain == nullptr)
			theTrain = new GearTrain();

		feedbackLabel->Text = "Adding new gear";
		currGear = new Gear2D();
		theTrain->addGear(*currGear);
		GearEditor gearForm(currGear);
		gearForm.ShowDialog();
		theTrain->recalcTrain();
		mainPanel->Refresh();
		updatePropertiesDisplay();
	}
	private: System::Void buttonAddDriver_Click(System::Object^ sender, System::EventArgs^ e) {
		if (currGear != nullptr) {
			labelDriverID->Text = "";
			IO::Stream^ myStream; // needed to capture the results
			OpenFileDialog^ theDialog = gcnew OpenFileDialog;

			theDialog->InitialDirectory = ".";  // current folder
			theDialog->Filter = "Driver files (*.driver)|*.driver|All files (*.*)|*.*";
			theDialog->FilterIndex = 1;  // will show only linkage files, but user can choose to show all files
			theDialog->Multiselect = false;  // this is the default, but nice to know
			theDialog->RestoreDirectory = true; // will remember last directory/folder used

			// actually open the file dialog and get the name of the file user wants
			if (theDialog->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
				// user did not press cancel button nor closed the dialog
				// create filestream for the file
				if ((myStream = theDialog->OpenFile()) != nullptr)
				{
					feedbackLabel->Text = theDialog->FileName + " is opening";

					myStream->Close();  // don't need it anymore
					std::ifstream inFile;
					inFile.open(StringPlus::convertString(theDialog->FileName)); // needs StringPlus.h

					if (inFile.is_open()) {
						// do whatever you need with inFile (like use it to create a gear train, maybe)

						// if there is a gear already, clear the memory (instead of just abandon it)
						if (theDriver != nullptr)
							delete theDriver;  // follow the pointer and "release" the memory

						theDriver = new Driver(inFile); // allocate new memory and let my variable point to it

						inFile.close();

						labelDriverID->Text = gcnew String(theDriver->getID().c_str());
						theDriver->setDrivenGear(currGear);

					}
					else {
						// provide feedback that you were unable to open file ???
						feedbackLabel->Text = " ERROR: Could not open " + theDialog->FileName;
					}
				}
			}
		}
		else {
			feedbackLabel->Text = " Must select a gear before applying a driver";
		}
	}

	private: void changeEnablingAllButtons(bool makeEnabled) {
		buttonMeshCurrGear->Enabled = makeEnabled;
		buttonAttachCurrGear->Enabled = makeEnabled;
		buttonBeltCurrGear->Enabled = makeEnabled;
		buttonUnmeshCurrGear->Enabled = makeEnabled;
		buttonDetachCurrGear->Enabled = makeEnabled;
		buttonEditCurrGear->Enabled = makeEnabled;
		buttonDelCurrGear->Enabled = makeEnabled;
		buttonLoad->Enabled = makeEnabled;
		buttonSave->Enabled = makeEnabled;
		buttonResetAll->Enabled = makeEnabled;
		buttonAddGear->Enabled = makeEnabled;
		buttonAddDriver->Enabled = makeEnabled;
		buttonSimulation->Enabled = makeEnabled;
	}
	private: System::Void buttonHelp_Click(System::Object^ sender, System::EventArgs^ e) {
		// note that the backslash character in a string is '\\'

		//LPCTSTR localLink = L"C:\\cpp_ng\\gearEditor_ps05_ng27\\gearEditor_ps05_ng27\\Help01.htm";
		LPCTSTR localLink = L".\\Help01.htm";
		ShellExecute(NULL, L"open", localLink, NULL, NULL, SW_SHOWDEFAULT);

		//LPCTSTR notepad = L"C:\\Windows\\System32\\notepad.exe";
		//LPCTSTR notepadFile = L"C:\\cpp_ng\\ps04_meshviewer_ng27\\ps04_meshviewer_ng27\\QuarterCircle.fem";

		//LPCTSTR winWord = L"C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE";
		//ShellExecute(NULL, L"open", notepad, notepadFile, NULL, SW_SHOWDEFAULT);

	}
	public: void refreshAll() {
		//mainPanel->Refresh();
		updatePropertiesDisplay();
		Refresh();
	}
	public: void showFeedback(String^ aMessage) {
		feedbackLabel->Text = aMessage;

		if (aMessage->IndexOf("Done") != -1)  // the word "Done" is in message
			turnButtonGreen();

		Refresh();
	}
	private: void turnButtonRed() {
		// turn button red
		buttonSimulation->BackColor = Color::Red;
		buttonSimulation->Text = "Stop Simulation";
		buttonSimulation->ForeColor = Color::White;

	}

	private: void turnButtonGreen() {
		// turn button green
		buttonSimulation->Text = "Start Simulation";
		buttonSimulation->BackColor = Color::Lime;
		buttonSimulation->ForeColor = Color::Black;

	}
	private: System::Void buttonSimulation_Click(System::Object^ sender, System::EventArgs^ e) {
		if (theDriver != nullptr) {
			if (buttonSimulation->Text == "Start Simulation") {
				turnButtonRed();
				// want to start a new thread 
				using namespace System::Threading;

				// yes allow cross-thread calls (duh!)
				System::Windows::Forms::Form::CheckForIllegalCrossThreadCalls = false;

				// create the thread
				Thread^ simulationThread =
					gcnew Thread(gcnew ThreadStart(this, &GearSimulator::runSimulation));

				// start the thread
				simulationThread->Start();

				//simulationThread->Join(); // not needed/wanted
			}
			else {
				theDriver->stop();
				turnButtonGreen();
			}
		}
		else
			feedbackLabel->Text = "Must assign driver to a gear in order to run simulation.";
	}

		   // thread entry point
	public: void runSimulation() {
		if (theDriver != nullptr) {
			theDriver->simulate(0.05, this);
		}
	}
	private: System::Void buttonBeltCurrGear_Click(System::Object^ sender, System::EventArgs^ e) {
		if (theTrain != nullptr) {
			if (currGear != nullptr) {
				if (otherGear == nullptr) {
					if (waitingForOtherGearToBelt) {
						// cancel belt operation
						waitingForOtherGearToBelt = false;
						changeEnablingAllButtons(!waitingForOtherGearToBelt);
						feedbackLabel->Text = "Cancelled belt operation";
					}
					else {
						feedbackLabel->Text = "Select other gear to belt to or Belt Button without selection to cancel.";
						waitingForOtherGearToBelt = true;
						changeEnablingAllButtons(!waitingForOtherGearToBelt);
						buttonBeltCurrGear->Enabled = true;
					}
				}
				else {
					// do the belting
					theTrain->beltGears(*currGear, *otherGear);
					otherGear = nullptr;
					waitingForOtherGearToBelt = false;
					changeEnablingAllButtons(!waitingForOtherGearToBelt);
				}
			}
			else
				feedbackLabel->Text = "Must select a gear before trying to belt";

			mainPanel->Refresh();
		}
		else
			feedbackLabel->Text = "No gears to belt";

	}
private: System::Void buttonUnbeltCurrGear_Click(System::Object^ sender, System::EventArgs^ e) {
	if (theTrain != nullptr && currGear != nullptr) {
		// confirm that user wants to delete
		std::string message = "Are you sure you want to unbelt gear " + currGear->getID() + " from all other gears?";
		auto result = MessageBox::Show(this, gcnew String(message.c_str()), "CONFIRM",
			MessageBoxButtons::YesNo, MessageBoxIcon::Question);
		if (result == System::Windows::Forms::DialogResult::Yes) {
			feedbackLabel->Text = "Gear " + gcnew String(currGear->getID().c_str()) + " has been unbelted";
			currGear->unbeltAll();
			//currGear = nullptr;
			//mainPanel->Refresh();
			//updatePropertiesDisplay();
		}

	}
}
};
}
