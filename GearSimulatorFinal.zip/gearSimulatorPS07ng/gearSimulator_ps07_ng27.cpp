#define MAIN_FORM GearSimulator
#define PROJECT_NAME gearSimulatorPS07ng
#include "GearSimulator.h"

using namespace System;
using namespace System::Windows::Forms;

[STAThreadAttribute]
int main(cli::array <String^>^ args) {
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	PROJECT_NAME::MAIN_FORM form;
	Application::Run(% form);
	return 0;
}

#undef MAIN_FORM
#undef PROJECT_NAME