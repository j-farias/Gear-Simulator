#include <math.h>

#include "Line2D.h"

using namespace std;

double Line2D::getLength(Point2D startPoint, Point2D endPoint)
{
	return getLength(startPoint.x, startPoint.y, endPoint.x, endPoint.y);
}

double Line2D::getLength(float startX, float startY, float endX, float endY)
{
	float deltaX = endX - startX;
	float deltaY = endY - startY;
	return sqrt(deltaX * deltaX + deltaY * deltaY);
}

bool Line2D::isBetween(Point2D startPoint, Point2D endPoint, Point2D checkPoint)
{
	float length = getLength(startPoint, endPoint);// *1e-5;
	float delta1 = getLength(startPoint, checkPoint);
	float delta2 = getLength(endPoint, checkPoint);
	return fabs(length - delta1 - delta2) < length * 1e-5;
}

Point2D Line2D::getIntersection(Point2D pnt1, Point2D pnt2, Point2D pnt3, Point2D pnt4)
{
	float denominator = (pnt1.x - pnt2.x) * (pnt3.y - pnt4.y) - (pnt1.y - pnt2.y) * (pnt3.x - pnt4.x);
	if (fabs(denominator) < 1e-8) // lines are parallel
		return { -INFINITY, -INFINITY };
	else {
		float topX = (pnt1.x * pnt2.y - pnt1.y * pnt2.x) * (pnt3.x - pnt4.x)
			- (pnt1.x - pnt2.x) * (pnt3.x * pnt4.y - pnt3.y * pnt4.x);

		float topY = (pnt1.x * pnt2.y - pnt1.y * pnt2.x) * (pnt3.y - pnt4.y)
			- (pnt1.y - pnt2.y) * (pnt3.x * pnt4.y - pnt3.y * pnt4.x);

		return { topX / denominator, topY / denominator };
	}
}

Point2D Line2D::getTrueIntersection(Point2D start1, Point2D end1, Point2D start2, Point2D end2)
{
	Point2D maybeIntersect = getIntersection(start1, end1, start2, end2); // mathematical intersection
	if (maybeIntersect.x != -INFINITY) { // lines not parallel
		// for true intersect, intersection point must line on both line segments
		if (!(isBetween(start1,end1,maybeIntersect) && isBetween(start2, end2, maybeIntersect)))  
			maybeIntersect = { -INFINITY, -INFINITY };
	}
	return maybeIntersect;
}

Point2D Line2D::scale(Point2D startPnt, Point2D endPnt, float fraction)
{
	Point2D result;
	result.x = startPnt.x + (endPnt.x - startPnt.x) * fraction;
	result.y = startPnt.y + (endPnt.y - startPnt.y) * fraction;
	return result;
}

Point2D Line2D::getPerpendicular(Point2D startPnt, Point2D endPnt)
{
	Point2D result;
	float segLength = getLength(startPnt, endPnt);

	result.x = startPnt.x - (endPnt.y - startPnt.y) / segLength;
	result.y = startPnt.y + (endPnt.x - startPnt.x) / segLength;

	return result;
}

float Line2D::getAngle(Point2D startPnt, Point2D endPnt)
{
	float answer = atan2(endPnt.y - startPnt.y, endPnt.x - startPnt.x) * 45. / atan(1.); // 45 deg = PI/2 = atan(1.)
	return fmodf(answer + 360., 360.);
}

Point2D Line2D::rotatePoint(Point2D aPoint, Point2D centerPnt, float theta)
{
	float dx = aPoint.x - centerPnt.x;
	float dy = aPoint.y - centerPnt.y;
	double thetaRad = theta * atan(1.) / 45.;

	float newX = centerPnt.x + dx * cos(thetaRad) - dy * sin(thetaRad);
	float newY = centerPnt.y + dx * sin(thetaRad) + dy * cos(thetaRad);
	return { newX, newY };
}
