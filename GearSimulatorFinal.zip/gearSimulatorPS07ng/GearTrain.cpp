#include <algorithm>
#include "GearTrain.h"

using namespace std;
using namespace System::Drawing;
using namespace System::Collections::Generic;

std::ostream& operator<<(std::ostream& os, const GearTrain& aTrain)
{
	os << "gearTrainID: " << aTrain.gearTrainID << endl;
	for (auto currGear : aTrain.theGears) {
		os << *currGear;
	}

	os << "Meshing:" << endl;
	for (auto currGear : aTrain.theGears) {
		os << currGear->listMeshedGears();
	}
	os << "End Meshing:" << endl;

	os << "Attachments:" << endl;
	for (auto currGear : aTrain.theGears) {
		os << currGear->listAttachedGears();
	}
	os << "End Attachments:" << endl;

	return os;
}

void GearTrain::readFile(std::ifstream& input)
{
	string wholeLineString;
	stringstream wholeLineStream;
	bool continueReading = true;

	while (continueReading && !input.eof()) {
		getline(input, wholeLineString);
		int colonLocation = wholeLineString.find(":");
		if (colonLocation != string::npos)
			wholeLineStream.str(wholeLineString.substr(colonLocation + 1));

		if (wholeLineString.find("gearTrainID") != string::npos) {
			gearTrainID = StringPlus::trim(
				wholeLineString.substr(colonLocation + 1));
		}
		else if (wholeLineString.find("Gear:") != string::npos) {
			Gear2D* newGear = new Gear2D(input);
			theGears.push_back(newGear);
			addGear(*newGear);
		}
		else if (wholeLineString.find("Meshings:") != string::npos) {
			// get and apply all the meshings
			getline(input, wholeLineString);
			while (wholeLineString.find("End Meshings:") == string::npos) {
				auto gearPair = StringPlus::split(wholeLineString, "\t");
				auto gear1 = getGear(gearPair[0]);
				auto gear2 = getGear(gearPair[1]);
				meshGears(*gear1, *gear2);
				getline(input, wholeLineString);
			}
		}
		else if (wholeLineString.find("Attachments:") != string::npos) {
			// get and apply all the meshings
			getline(input, wholeLineString);
			while (wholeLineString.find("End Attachments:") == string::npos) {
				auto gearPair = StringPlus::split(wholeLineString, "\t");
				attachGears(*(getGear(gearPair[0])), *(getGear(gearPair[1]))); // same as above, only crazier syntax
				getline(input, wholeLineString);
			}
		}
	}

	recalcTrain();
}

bool GearTrain::areMeshable(const Gear2D& gear1, const Gear2D& gear2)
{
	return gear1.isMeshableWith(gear2);
}

bool GearTrain::meshGears(Gear2D& newGear, Gear2D& oldGear)
{
	bool meshSuccessful = newGear.meshWith(oldGear);
	if (meshSuccessful)
		recalcTrain();

	return meshSuccessful;
}

bool GearTrain::attachGears(Gear2D& newGear, Gear2D& oldGear)
{
	bool attachSuccessful = newGear.attachTo(oldGear);
	if (attachSuccessful)
		recalcTrain();

	return attachSuccessful;
}

bool GearTrain::beltGears(Gear2D& newGear, Gear2D& oldGear)
{
	bool attachSuccessful = newGear.beltTo(oldGear);
	if (attachSuccessful)
		recalcTrain();
		
	return attachSuccessful;
}

bool GearTrain::addGear(Gear2D& aGear)
{
	bool foundGear = false;
	for (auto currGear : theGears) {
		if (currGear == &aGear) {
			foundGear = true;
			break;      // exit for-loop
		}
	}

	if (!foundGear) {
		theGears.push_back(&aGear);
		recalcTrain();
	}

	return !foundGear;
}

bool GearTrain::deleteGear(Gear2D& aGear)
{
	int i = 0;
	for (auto currGear : theGears) {
		if (currGear == &aGear) {
			theGears.erase(theGears.begin() + i);
			delete currGear;
			recalcTrain();
			return true;
		}
		i++;
	}
	return false;
}

Gear2D* GearTrain::getGear(std::string givenGearID)
{
	for (auto currGear : theGears) {
		if (currGear->getID() == givenGearID)
			return currGear;
	}
}

Gear2D* GearTrain::getGear(Point2D givenCoords)
{
	for (auto currGear : theGears) {
		if (currGear->isContained(givenCoords))
			return currGear;   // possible exit from function
	}
	return nullptr;
}

void GearTrain::resetAll()
{
	for (auto currGear : theGears) {
		currGear->reset();
	}
}

void GearTrain::paint(System::Drawing::Graphics^ g)
{
	for (auto currGear : theGears) {
		currGear->paint(g, nullptr, true, false, false, true, true);
	}

	

	//if (currGearIndex != -1) {
	//	// highlight current gear
	//	theGears.at(currGearIndex)->paint(g, Color::Green, true, false, false, true, true);
	//}

	//if (otherGearIndex != -1) {
	//	// highlight current gear
	//	theGears.at(otherGearIndex)->paint(g, Color::Red, true, false, false, true, true);
	//}

}

void GearTrain::recalcTrain()
{
	if (theGears.size() > 0) {
		auto minPoint = theGears.front()->lowerBoundingBox();
		auto maxPoint = theGears.front()->upperBoundingBox();
		maxX = maxPoint.x; maxY = maxPoint.y;
		minX = minPoint.x; minY = minPoint.y;

		for (int i = 1; i < theGears.size(); i++) {
			minPoint = theGears.at(i)->lowerBoundingBox();
			maxPoint = theGears.at(i)->upperBoundingBox();
			maxX = max(maxX, maxPoint.x);
			maxY = max(maxY, maxPoint.y);
			minX = min(minX, minPoint.x);
			minY = min(minY, minPoint.y);
		}
	}
	else {
		minX = minY = maxX = maxY = 0.f;
	}
}

int GearTrain::getIndexFromGear(Gear2D& aGear)
{
	bool foundGear = false;
	int i = 0;
	for (auto currGear : theGears) {
		if (currGear == &aGear) {
			foundGear = true;
			break;      // exit for-loop
		}
		i++;
	}

	if (foundGear)
		return i;
	else
		return -1;

}

