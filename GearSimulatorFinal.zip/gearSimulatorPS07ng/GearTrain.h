/*			_____
		   /     \
		  /       \				Nestor Gomez
	,----<         >----.		Carnegie Mellon University
   /                     \		C++ for Engrs, 24-280
  /                       \		Prob Set 6. Due Thurs. Apr. 14, 2022
  \                       /
   \                     /
	>                   <		The GearTrain class models a a collection
   /                     \		of gears and how they interact with each
  /                       \		other (meshing and attaching)
  \                       /		
   \                     /
	`----<         >----'
		  \       /
		   \_____/
*/

#pragma once
#include <vector>
#include "Gear2D.h"

class GearTrain {
	std::string gearTrainID;
//	int currGearIndex = -1, otherGearIndex = -1;
	float timeStep; // seconds

	float minX, maxX, minY, maxY; // bounding box (for graphics mostly)

	std::vector<Gear2D*> theGears;

public:
	// default constructor for the class. Initializes member variables
	// including dependent member variables minX, minY, maxX, and maxY, etc.).
	GearTrain() { minX = minY = maxX = maxY = 0.f; };
	
	// additional constructor for the class. Takes a pre-created ifstream and uses it to read
	// the properties of the gear train. Also needs to instantiate any constituent objects
	// and/or data structures
	GearTrain(std::ifstream& input) : GearTrain() { readFile(input); };
	
	// takes a pre-created ifstream and uses it to read the constituent gears.
	// may also need to initialize any constituent objects and/or data structures
	void readFile(std::ifstream& input);
	
	// writes gear train parameters and gear information to given output stream
	friend std::ostream& operator<<(std::ostream& os, const GearTrain& aTrain);;
	
	// determines if the two given gears can be meshed using function in Gear2D class
	bool areMeshable(const Gear2D& gear1, const Gear2D& gear2);
	
	// attempts to mesh the newGear into the oldGear, returns false if it cannot be done
	// note that newGear will need to be moved and rotated (its start angle changed) so that it can
	// properly mesh into oldGear. calls the proper function in Gear2D class
	bool meshGears(Gear2D& newGear, Gear2D& oldGear);

	// attempts to attach the newGear to the oldGear, returns false if it cannot be done
	// note that newGear will need to be moved so that its center matches that of oldGear
	// calls the proper function in Gear2D class
	bool attachGears(Gear2D& newGear, Gear2D& oldGear);

	
	// attempts to belt the newGear to the oldGear, returns false is it cannot be done
	// note that newGear will not move 
	bool beltGears(Gear2D& newGear, Gear2D& oldGear);
	
	// adds a gear to the gear train, without meshing or attaching
	bool addGear(Gear2D& aGear);

	// removes a gear from the gear train
	bool deleteGear(Gear2D& aGear);

	// finds a gear in the gear train given the ID of the gear
	// returns nullptr if gear is not found
	Gear2D* getGear(std::string givenGearID);
	
	// finds a gear in the gear train given the coordinates of a selected point
	// uses Gear2D::isContained() and returns nullptr if no gear found
	Gear2D* getGear(Point2D givenCoords);
	
	// return a point corresponding to the lower left corner of a bounding box for the shape
	// (minimum X and minimum Y value of all points).
	void resetAll();
	
	// generates the geometry of the gear train on the given graphic space, including all gears
	// parameters, highlighting the current gear in some way
	void paint(System::Drawing::Graphics^ g);

	// return a point corresponding to the upper right corner of a bounding box for the gear train  
	// (maximum X and maximum Y value of all points). 
	Point2D upperBoundingBox() { return { maxX, maxY }; };

	// return a point corresponding to the lower left corner of a bounding box for the gear train
	// (minimum X and minimum Y value of all points). 
	Point2D lowerBoundingBox() { return { minX, minY }; };

	std::string getID() const { return gearTrainID; };
	void setID(std::string newID) { gearTrainID = StringPlus::trim(newID); };

	// this now has to be public so that I can call it when I edit a gear
public:	void recalcTrain();

protected:	int getIndexFromGear(Gear2D& aGear);

};