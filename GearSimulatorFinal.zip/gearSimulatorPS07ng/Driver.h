#pragma once
//#include "GearSimulator.h"  // cannot include because it creates inclusion loop
#include "Shape2D.h"
#include "GearTrain.h"


class Driver {
	std::string driverID = "";
	Shape2D* inputMotion = nullptr;  // x = time (in seconds), y = rotation at time x, interpolate in between
	bool cyclical = false;
	float currTime = 0.f;
	bool simulationIsRunning = false;

	Gear2D* drivenGear = nullptr;
	//GearTrain* theGearTrain = nullptr; 

public:
	// default constructor for the class. Initializes member variables
	// (none so far)
	Driver() { };

	// additional constructor for the class. Takes a pre-created ifstream and uses it to
	// read the parameters of the driver. Also needs to instantiate any constituent objects
	// and/or data structures
	Driver(std::ifstream& input) : Driver() { readFile(input); };

	// takes a pre-created ifstream and uses it to read the driver parameters
	// may also need to initialize any constituent objects and/or data structures
	void readFile(std::ifstream& input);

	// writes gear train parameters and gear information to given output stream
	friend std::ostream& operator<<(std::ostream& os, const Driver& aDriver);

	// runs a simulation (the link to Form is so that graphics can be updated as it runs)
	void simulate(float timeStep, System::Windows::Forms::Form^ theSimulator);

	// resets the simulation;
	void reset() { currTime = 0.f; }

	// will cause the simulation to stop running 
	// (only works when multi-threading is used)
	void stop() { simulationIsRunning = false; }

	void setDrivenGear(Gear2D* aGear) { 
		if (!simulationIsRunning) // cannot change gear while simulation is running ?
			drivenGear = aGear; 
	}

	Gear2D* getDrivenGear(Gear2D* aGear) { return drivenGear; }

	std::string getID() { return driverID; }

};